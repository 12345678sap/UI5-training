jQuery.sap.declare("hcm.approve.timesheet.ZHCM_TSH_APVEXT.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
  name: "hcm.approve.timesheet",  
  url: jQuery.sap.getModulePath("hcm.approve.timesheet.ZHCM_TSH_APVEXT") + "/../{parent project url}" // provide parent project url
  // we use a URL relative to our own component; might be different if
  // extension app is deployed with customer namespace
});


hcm.approve.timesheet.Component.extend("hcm.approve.timesheet.ZHCM_TSH_APVEXT.Component", {
  metadata: {
    version : "1.0",
    config : {
      "sap.ca.i18Nconfigs": {
        "bundleName":"hcm.approve.timesheet.ZHCM_TSH_APVEXT.i18n.i18n"
      },

            "sap.ca.serviceConfigs": [{
              name: "HCM_TIMESHEET_APPROVE_SRV",
                serviceUrl: "/sap/opu/odata/sap/ZHTR_TIMESHEET_APPROVE_SRV/",
                isDefault: true
             }],
    },

    customizing: {
      "sap.ui.controllerExtensions": {
        "hcm.approve.timesheet.view.S3": {
          controllerName: "hcm.approve.timesheet.ZHCM_TSH_APVEXT.view.S3Custom",
        }


      },

      "sap.ui.viewReplacements": {
        "hcm.approve.timesheet.view.S3": {
          viewName: "hcm.approve.timesheet.ZHCM_TSH_APVEXT.view.S3Custom",
          type: "XML",
        },
      },

    }
  }
});