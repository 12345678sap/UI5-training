/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("hcm.approve.timesheet.util.DataManager");
jQuery.sap.require("hcm.approve.timesheet.util.Formatter");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
sap.ca.scfld.md.controller.BaseDetailController.extend("hcm.approve.timesheet.ZHCM_TSH_APVEXT.view.S3Custom", {
	extHookcreateDetailModelData: null,
	extHookviewSummary: null,
	extHookChangeFooterButtons: null,
	getWeeklyPendingEntriesCount: function () {
		var n = 0;
		var a = this.byId("S3IconTabBar");
		var S = a.getSelectedKey();
		for (var k = 0; k < a.getItems().length; k++) {
			if (a.getItems()[k].getKey() === S) {
				var I = this.byId("S3IconTabBar").getItems()[k].getContent()[0].getItems();
				break;
			}
		}
		for (var i = 0; i < I.length; i++) {
			var c = I[i].getCells()[1];
			if (c.getEnabled() === true) {
				n++;
			}
		}
		return n;
	},
	updateModel: function () {
		this.updateFlag = true;
		this.setBtnEnabled("ApproveBtn", false);
		this.setBtnEnabled("RejectBtn", false);
		var e = sap.ui.getCore().getEventBus();
		e.publish("hcm.approve.timesheet", "timesheetApproveReject", this.pernr);
	},
	refreshDetail: function (c, e, d) {
		this.IndividualMasterData = this.oApplication.getModel("masterModel").getData().MasterModelDataCollection[d.pos];
		this.pernr = this.IndividualMasterData.PERNR;
		var s = this.IndividualMasterData.STARTDATE;
		var a = this.IndividualMasterData.ENDDATE;
		this.filter = "PERNR eq '" + this.pernr + "' and STARTDATE eq '" + s + "'and ENDDATE eq '" + a + "'";
		this._initData(this.filter, this.IndividualMasterData);
		this.setDetailObjectHdr(this.IndividualMasterData);
	},
	setButtonState: function (e) {
		var i = this.byId("S3IconTabBar");
		var S = i.getSelectedKey();
		var c = this.fetchSelectedCounters();
		this.lSelectedCounters = c[0];
		this.lLaeda = c[1];
		this.lLaetm = c[2];
		if (this.lSelectedCounters.length !== 0) {
			this.setBtnEnabled("ApproveBtn", true);
			this.setBtnEnabled("RejectBtn", true);
		} else {
			this.setBtnEnabled("ApproveBtn", false);
			this.setBtnEnabled("RejectBtn", false);
		}
		var s = this.getWeeklyPendingEntriesCount();
		if (s === this.lSelectedCounters.length) {
			for (var k = 0; k < i.getItems().length; k++) {
				if (i.getItems()[k].getKey() === S) {
					this.byId("S3IconTabBar").getItems()[k].getContent()[0].getColumns()[1].getHeader().setSelected(true);
					this.prevAllSelected = true;
					break;
				}
			}
		} else if (this.prevAllSelected === true) {
			for (var k = 0; k < i.getItems().length; k++) {
				if (i.getItems()[k].getKey() === S) {
					this.byId("S3IconTabBar").getItems()[k].getContent()[0].getColumns()[1].getHeader().setSelected(false);
					this.prevAllSelected = false;
					break;
				}
			}
		}
	},
	reset: function () {
		var i = this.byId("S3IconTabBar");
		for (var k = 0; k < i.getItems().length; k++) {
			if (i.getItems()[k].getKey() === this.prevIconTabFilter) {
				this.byId("S3IconTabBar").getItems()[k].getContent()[0].getColumns()[1].getHeader().setSelected(false);
				this.selectAllCheckBoxes();
				break;
			}
		}
		this.prevIconTabFilter = this.byId("S3IconTabBar").getSelectedKey();
	},
	selectAllCheckBoxes: function (e) {
		var a = this.byId("S3IconTabBar");
		var h, S;
		if (e) {
			h = e.getParameters().selected;
			S = a.getSelectedKey();
		} else {
			h = false;
			S = this.prevIconTabFilter;
		}
		for (var k = 0; k < a.getItems().length; k++) {
			if (a.getItems()[k].getKey() === S) {
				var I = this.byId("S3IconTabBar").getItems()[k].getContent()[0].getItems();
				break;
			}
		}
		for (var i = 0; i < I.length; i++) {
			var c = I[i].getCells()[1];
			if (c.getEnabled() === true) {
				c.setSelected(h);
			}
		}
		if (h === true) {
			this.setBtnEnabled("ApproveBtn", true);
			this.setBtnEnabled("RejectBtn", true);
			this.prevAllSelected = true;
		} else {
			this.setBtnEnabled("ApproveBtn", false);
			this.setBtnEnabled("RejectBtn", false);
			this.prevAllSelected = true;
		}
		var b = this.fetchSelectedCounters();
		this.lSelectedCounters = b[0];
		this.lLaeda = b[1];
		this.lLaetm = b[2];
	},
	fetchSelectedCounters: function (e) {
		var a = this.byId("S3IconTabBar");
		var S = a.getSelectedKey();
		for (var k = 0; k < a.getItems().length; k++) {
			if (a.getItems()[k].getKey() === S) {
				var I = this.byId("S3IconTabBar").getItems()[k].getContent()[0].getItems();
				break;
			}
		}
		var c = [],
			l = [],
			L = [];
		for (var i = 0; i < I.length; i++) {
			var C = I[i].getCells()[1];
			if (C.getSelected() === true) {
				c.push(I[i].getCells()[1].getCustomData()[0].getValue());
				l.push(I[i].getCells()[1].getCustomData()[1].getValue());
				L.push(I[i].getCells()[1].getCustomData()[2].getValue());
			}
		}
		return [c, l, L];
	},
	setSelectedRejectionReason: function (r) {
		this.Reason = r.REASON;
		var R = null;
		if (this.lSelectedCounters.length > 1) {
			if (this.resourceBundle.sLocale === 'ja') {
				R = this.resourceBundle.getText("TSA_REJS_CONF");
			} else {
				R = this.resourceBundle.getText("TSA_REJS_CONF") + " " + this.EMPNAME + "?";
			}
		} else {
			if (this.resourceBundle.sLocale === 'ja') {
				R = this.resourceBundle.getText("TSA_REJ_CONF");
			} else {
				R = this.resourceBundle.getText("TSA_REJ_CONF") + " " + this.EMPNAME + "?";
			}
		}
		var l = this.confirmationTextBoxView(R);
		sap.ca.ui.dialog.factory.confirm(l, jQuery.proxy(function (a) {
			if (a.isConfirmed === true) {
				var s = this.createSubmitStr("R", this.Reason);
				s += "'";
				var c = "CATS_ACTION?" + s;
				hcm.approve.timesheet.util.DataManager.submitPendingEntries(c, jQuery.proxy(function (d, o) {
					sap.ca.ui.message.showMessageToast(this.resourceBundle.getText("CATS_SUCCESS_MESSAGE"));
					this.updateModel();
				}, this));
			}
		}, this));
	},
	createSubmitStr: function (s, r) {
		var a = "cats='";
		for (var i = 0; i < this.lSelectedCounters.length; i++) {
			a += this.pernr + "," + this.lSelectedCounters[i] + "," + s + "," + r + "," + hcm.approve.timesheet.util.Formatter.LastDateTimeFormatter(
				this.lLaeda[i], this.lLaetm[i].ms) + "/";
		}
		return a;
	},
	confirmationTextBoxView: function (C) {
		var s = {
			question: C,
			showNote: false,
			title: this.resourceBundle.getText("TSA_CONF_HEADER"),
			confirmButtonLabel: "OK"
		};
		return s;
	},
	viewSummary: function (e) {
		if (this.extHookviewSummary) {
			this.extHookviewSummary(e);
		} else {
			var c = e.getSource().getCustomData()[0]
				.getValue("counter");
			var a = this.byId("S3IconTabBar");
			var s = a.getSelectedKey();
			var b = null;
			for (var l = 0; l < a.getItems().length; l++) {
				if (a.getItems()[l].getKey() === s) {
					b = this.byId("S3IconTabBar").getItems()[l];
					break;
				}
			}
			var n = [];
			var w = b.getCustomData()[0].getValue();
			var d = this.oView.getModel("a").getData().DetailModelDataCollection;
			var f = d[w].PENDING_ENTRIES;
			for (var i = 0; i < f.length; i++) {
				if (f[i].COUNTER === c) {
					n
						.push({
							"title": this.resourceBundle
								.getText("TSA_DATE"),
							"description": hcm.approve.timesheet.util.Formatter
								.DateFormatter(f[i].WORKDATE)
						});
					n
						.push({
							"title": this.resourceBundle
								.getText("TSA_DESCRIPTION"),
							"description": hcm.approve.timesheet.util.Formatter
								.newLineAdder(
									f[i].MAIN_FIELD_TEXT,
									f[i].SUB_FIELDS_TEXT)
						});
					n
						.push({
							"title": this.resourceBundle
								.getText("TSA_TIME_RECORDED"),
							"description": hcm.approve.timesheet.util.Formatter
								.unitAppender(
									f[i].CATSHOURS,
									f[i].CATSUNIT)
						});
					if (f[i].Sender_CCtr !== "") {
						var sc = f[i].Sender_CCtr + "\n" + f[i].Sendercctr_des;

						n.push({
							"title": "Sender Cost Center",
							"description": sc
						});
					}
					if (f[i].Rec_CCtr !== "") {
						var rc = f[i].Rec_CCtr + "\n" + f[i].Recievercctr_des;

						n.push({
							"title": "Receiver Cost Center",
							"description": rc
						});
					}
					if (f[i].Network_number !== "") {
						var nc = f[i].Network_number + "\n" + f[i].Network_des;

						n.push({
							"title": "Network Number",
							"description": nc
						});
					}
					if (f[i].Activity_number !== "") {
						var ac = f[i].Activity_number + "\n" + f[i].Activity_des;

						n.push({
							"title": "Activity Number",
							"description": ac
						});
					}
					var g = f[i].NOTES;
					var r = f[i].REJ_REASON;
					if (g || r) {
						if (g) {
							n.push({
								"title": this.resourceBundle
									.getText("TSA_NOTES"),
								"description": g
							});
						}
						if (r) {
							var h = null;
							var C = hcm.approve.timesheet.util.DataManager
								.getCachedModelObjProp("RejectionReason");
							if (!C) {
								hcm.approve.timesheet.util.DataManager
									.getRejectionReasons(
										jQuery
										.proxy(
											function (
												A) {},
											this),
										function (A) {
											hcm.approve.timesheet.util.DataManager
												.processError(A);
										});
								C = hcm.approve.timesheet.util.DataManager
									.getCachedModelObjProp("RejectionReason");
							}
							for (var j = 0; j < C.length; j++) {
								if (C[j].REASON === r) {
									h = C[j].TEXT;
								}
							}
							n
								.push({
									"title": this.resourceBundle
										.getText("TSA_TIT_REJECTION_REASON"),
									"description": h
								});
						}
					}
					if (f[i].oPastEntries) {
						for (var k = 0; k < f[i].oPastEntries.length; k++) {
							var p = f[i].oPastEntries[k].CATSHOURS;
							var m = f[i].oPastEntries[k].CATSUNIT;
							var o = f[i].oPastEntries[k].CHANGED_DATE;
							var q = f[i].oPastEntries[k].CHANGED_TIME;
							var t = f[i].oPastEntries[k].CHANGED_BY;
							n
								.push({
									"title": this.resourceBundle
										.getText("TSA_PAST_ENTRY"),
									"description": hcm.approve.timesheet.util.Formatter
										.unitAppender(
											p, m)
								});
							n
								.push({
									"title": this.resourceBundle
										.getText("TSA_CHANGED_DATETIME"),
									"description": hcm.approve.timesheet.util.Formatter
										.DateTimeFormatter(
											o, q)
								});
							n
								.push({
									"title": this.resourceBundle
										.getText("TSA_CHANGED_BY"),
									"description": t
								});
						}
					}
					break;
				}
			}
			var u = new sap.m.ColumnListItem({
				cells: [new sap.m.Label({
					text: "{title}"
				}), new sap.m.Text({
					text: "{description}"
				})]
			});
			var T = new sap.m.Table({
				columns: [new sap.m.Column(),
					new sap.m.Column()
				]
			});
			var v = function (e) {
				P.close();
			};
			var x = this.resourceBundle.getText("TSA_DETAILS");
			var y = e.getSource().getCustomData()[1]
				.getValue("empname");
			var P = new sap.m.ResponsivePopover({
				contentWidth: "40%",
				placement: sap.m.PlacementType.Left,
				title: hcm.approve.timesheet.util.Formatter
					.textAppender(x, y),
				content: T,
				beginButton: new sap.m.Button({
					text: this.resourceBundle
						.getText("TSA_ACCEPT"),
					press: v
				})
			});
			var z = new sap.ui.model.json.JSONModel({
				"Notes": n
			});
			T.bindAggregation("items", "/Notes", u);
			T.setModel(z);
			P.openBy(sap.ui.getCore()
				.byId(e.getParameters().id));
		}
	},
	handleSearch: function (e) {
		var v = e.getParameter("value");
		var f = new sap.ui.model.Filter("TEXT", sap.ui.model.FilterOperator.Contains, v);
		var b = e.getSource().getBinding("items");
		b.filter([f]);
	},
	handleClose: function (e) {
		var l = e.getParameters().selectedItem.getBindingContext().sPath;
		var a = l.split("/");
		var b = a[2];
		var C = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
		this.setSelectedRejectionReason(C[b]);
	},
	setRejectionReasons: function (C) {
		var d = {
			"RejectionReasonCollection": C
		};
		var m = new sap.ui.model.json.JSONModel(d);
		var r = new sap.m.StandardListItem({
			title: "{TEXT}",
			type: "Active"
		});
		var D = new sap.m.SelectDialog({
			title: this.resourceBundle.getText("TSA_TIT_REJECTION_REASON"),
			items: {
				path: "/RejectionReasonCollection",
				template: r
			},
			search: this.handleSearch,
			close: this.handleClose,
			confirm: jQuery.proxy(this.handleClose, this)
		});
		D.setModel(m);
		D.open();
	},
	setDetailObjectHdr: function (O) {
		this.EMPNAME = O.EMPNAME;
		var o = this.byId("DetailObjHdr");
		o.setTitle(O.EMPNAME);
		o.setNumber(hcm.approve.timesheet.util.Formatter.timeConverter(O.CATSHOURS));
		o.setNumberUnit(this.resourceBundle.getText("TSA_HRS_APPR"));
		this.byId("DetailObjHdrAttr1").setText(hcm.approve.timesheet.util.Formatter.weekAppender(O.NUM_WEEKS));
		this.byId("DetailObjHdrAttr2").setText(O.POSNAME);
		this.byId("DetailObjHdrStatus1").setText(hcm.approve.timesheet.util.Formatter.textAppender1(hcm.approve.timesheet.util.Formatter.timeConverter(
			O.APPROVEDHOURS), this.resourceBundle.getText("TSA_HOURS"), this.resourceBundle.getText("TSA_STAT_APPROVED")));
		this.byId("DetailObjHdrStatus2").setText(hcm.approve.timesheet.util.Formatter.textAppender1(hcm.approve.timesheet.util.Formatter.timeConverter(
			O.REJECTEDHOURS), this.resourceBundle.getText("TSA_HOURS"), this.resourceBundle.getText("TSA_STAT_REJ")));
	},
	_getStatusText: function (n) {
		switch (n) {
		case "20":
			return [this.resourceBundle.getText("TSA_STAT_FOR_APPR"), "None", true];
		case "30":
			return [this.resourceBundle.getText("TSA_STAT_APPROVED"), "Success", false];
		case "40":
			return [this.resourceBundle.getText("TSA_STAT_REJ"), "Error", false];
		case "50":
			return [this.resourceBundle.getText("TSA_STAT_CHANGED"), "Warning", true];
		}
	},
	_createDetailModelData: function (r) {
		var w = [];
		var a = {};
		var W = [];
		var p = {};
		var A = [];
		var d = 0;
		var b = [];
		var c, n, s = null;
		var t = 0.0,
			h = false;
		for (var i = 0; i < r.length; i++) {
			c = r[i].WEEKNR;
			if (i !== r.length - 1) {
				n = r[i + 1].WEEKNR;
			} else {
				n = undefined;
			}
			p = {};
			p.EMPNAME = r[i].EMPNAME;
			p.WORKDATE = r[i].WORKDATE;
			p.MAIN_FIELD_TEXT = r[i].MAIN_FIELD_TEXT;
			p.SUB_FIELDS_TEXT = r[i].SUB_FIELDS_TEXT;
			p.CATSHOURS = r[i].CATSHOURS;
			p.CATSUNIT = r[i].CATSUNIT;
			var e = r[i].STATUS;
			if (e === "20" || e === "30") {
				t += Number(p.CATSHOURS);
			}
			if (e === "20" && h !== true) {
				h = true;
			}
			s = this._getStatusText(r[i].STATUS);
			p.STATUS_TEXT = s[0];
			p.STATUS = s[1];
			p.CHECKBOX_STATE = s[2];
			p.CHECKBOX_SELECTED_STATE = false;
			p.COUNTER = r[i].COUNTER;
			p.REF_COUNTER = r[i].REF_COUNTER;
			p.CHANGED_DATE = r[i].CHANGED_DATE;
			p.CHANGED_TIME = r[i].CHANGED_TIME;
			p.CHANGED_BY = r[i].CHANGED_BY;
			p.Rec_CCtr = r[i].Rec_CCtr;
			p.Sender_CCtr = r[i].Sender_CCtr;
			p.Sendercctr_des = r[i].Sendercctr_des;
			p.Recievercctr_des = r[i].Recievercctr_des;
			p.Network_number = r[i].Network_number;
			p.Activity_number = r[i].Activity_number;
			p.Network_des = r[i].Network_des;
			p.Activity_des = r[i].Activity_des;
			if (r[i].CATSTEXT) {
				p.NOTES = r[i].CATSTEXT;
			} else {
				p.NOTES = r[i].NOTES;
			}
			p.REJ_REASON = r[i].REJ_REASON;
			if (p.NOTES || p.REJ_REASON) {
				p.moreInfoBtnStatus = true;
			} else {
				p.moreInfoBtnStatus = false;
			}
			if (e === "50") {
				A.push(p);
			} else {
				W.push(p);
			}
			if (c !== n) {
				for (var j = 0; j < A.length; j++) {
					var f = A[j].COUNTER;
					for (var k = 0; k < W.length; k++) {
						if (W[k].REF_COUNTER === f) {
							b.push(A[j]);
							W[k].moreInfoBtnStatus = true;
							W[k].STATUS1 = A[j].STATUS_TEXT;
							W[k].oPastEntries = b;
							b = [];
							break;
						}
					}
				}
				a.PENDING_ENTRIES = W;
				a.WEEK_START = r[i].WEEK_START;
				a.WEEK_END = r[i].WEEK_END;
				a.totalCatHours = t;
				a.weekTarget = r[i].WEEK_TARGET;
				a.tableID = "PendingEntriesTable" + r[i].WEEKNR;
				a.tabFilterID = "IconTabFilter" + r[i].WEEKNR;
				a.displayWeekNumber = d;
				a.MainCheckBoxState = h;
				a.MainCheckBoxSelectedState = false;
				if (a.PENDING_ENTRIES.length > 0) {
					w.push(a);
				}
				W = [];
				a = {};
				t = 0.0;
				h = false;
				d++;
			}
		}
		return w;
	},
	_initData: function (f, O) {
		this.setDetailObjectHdr(O);
		hcm.approve.timesheet.util.DataManager.getDetail(f, jQuery.proxy(function (o) {
			var D;
			if (this.extHookcreateDetailModelData) {
				D = this.extHookcreateDetailModelData(o);
			} else {
				D = this._createDetailModelData(o);
			}
			this.byId("RecordedTime").setText(hcm.approve.timesheet.util.Formatter.textFormatter(this.totalCatHours, O.TARGETHOURS));
			var d = new sap.ui.model.json.JSONModel({
				"DetailModelDataCollection": D
			});
			var v = this.getView();
			v.setModel(d, "a");
			this.byId("S3IconTabBar").setExpanded(true);
			if (!this.updateFlag) {
				this.byId("S3IconTabBar").setSelectedKey(D[0].tabFilterID);
				this.prevIconTabFilter = this.byId("S3IconTabBar").getSelectedKey();
			}
			this.updateFlag = false;
		}, this), function (o) {
			hcm.approve.timesheet.util.DataManager.processError(o);
		});
	},
	onInit: function () {
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		hcm.approve.timesheet.util.DataManager.init(this.oDataModel, this.resourceBundle);
		var e = sap.ui.getCore().getEventBus();
		e.subscribe("hcm.approve.timesheet", "refreshDetail", this.refreshDetail, this);
		if (!this.oApplication) {
			this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		}
		this.oRouter.attachRouteMatched(function (E) {
			if (E.getParameter("name") === "detail") {
				hcm.approve.timesheet.util.DataManager.init(this.oDataModel, this.resourceBundle);
				var c = decodeURIComponent(E.getParameter("arguments").contextPath);
				this.masterItem = Number(c.slice(c.indexOf("/") + 1, c.length));
				this.IndividualMasterData = this.oApplication.getModel("masterModel").getData().MasterModelDataCollection[this.masterItem];
				this.pernr = this.IndividualMasterData.PERNR;
				var s = this.IndividualMasterData.STARTDATE;
				var a = this.IndividualMasterData.ENDDATE;
				this.filter = "PERNR eq '" + this.pernr + "' and STARTDATE eq '" + s + "'and ENDDATE eq '" + a + "'";
				this._initData(this.filter, this.IndividualMasterData);
			}
		}, this);
	},
	getHeaderFooterOptions: function () {
		var o = {
			oPositiveAction: {
				sId: "ApproveBtn",
				sI18nBtnTxt: this.resourceBundle.getText("TSA_APPROVE"),
				bDisabled: true,
				onBtnPressed: jQuery.proxy(function () {
					var C, l;
					if (this.lSelectedCounters.length > 1) {
						if (this.resourceBundle.sLocale === 'ja') {
							C = this.resourceBundle.getText("TSA_APRS_CONF");
						} else {
							C = this.resourceBundle.getText("TSA_APRS_CONF") + " " + this.EMPNAME + "?";
						}
					} else {
						if (this.resourceBundle.sLocale === 'ja') {
							C = this.resourceBundle.getText("TSA_APR_CONF");
						} else {
							C = this.resourceBundle.getText("TSA_APR_CONF") + " " + this.EMPNAME + "?";
						}
					}
					l = this.confirmationTextBoxView(C);
					sap.ca.ui.dialog.factory.confirm(l, jQuery.proxy(function (r) {
						if (r.isConfirmed === true) {
							var s = this.createSubmitStr("A", "");
							s += "'";
							var c = "CATS_ACTION?" + s;
							hcm.approve.timesheet.util.DataManager.submitPendingEntries(c, jQuery.proxy(function (d, R) {
								sap.ca.ui.message.showMessageToast(this.resourceBundle.getText("CATS_SUCCESS_MESSAGE"));
								this.updateModel();
							}, this));
						}
					}, this));
				}, this)
			},
			oNegativeAction: {
				sId: "RejectBtn",
				sI18nBtnTxt: this.resourceBundle.getText("TSA_REJECT"),
				bDisabled: true,
				onBtnPressed: jQuery.proxy(function () {
					var C = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
					if (!C) {
						hcm.approve.timesheet.util.DataManager.getRejectionReasons(jQuery.proxy(function (a) {
							this.setRejectionReasons(a);
						}, this), function (a) {
							hcm.approve.timesheet.util.DataManager.processError(a);
						});
					} else {
						this.setRejectionReasons(C);
					}
				}, this)
			}
		};
		var m = new sap.ui.core.routing.HashChanger();
		var u = m.getHash();
		if (u.indexOf("Shell-runStandaloneApp") >= 0) {
			o.bSuppressBookmarkButton = true;
		}
		if (this.extHookChangeFooterButtons) {
			o = this.extHookChangeFooterButtons(o);
		}
		return o;
	}
});