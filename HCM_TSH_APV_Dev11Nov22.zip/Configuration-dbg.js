/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.approve.timesheet.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("hcm.approve.timesheet.Configuration", {

	oServiceParams: {
		serviceList: [
			{
				name: "HCM_TIMESHEET_APPROVE_SRV",
				masterCollection: "TIME_PENDING",
				serviceUrl: "/sap/opu/odata/sap/HCM_TIMESHEET_APPROVE_SRV/",
				isDefault: true,
				mockedDataSource: "/hcm.approve.timesheet/model/metadata.xml",
				useBatch: true
			}
		]
	},

	getServiceParams: function () {
		return this.oServiceParams;
	},

/*	getAppConfig: function() {
		return this.oAppConfig;
	},*/

	/*
	 * @inherit
	 */
	getServiceList: function () {
		return this.oServiceParams.serviceList;
	},
	getMasterKeyAttributes : function() {
		//return the key attribute of your master list item
		return ["Id"];
	}

});
