/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.approve.timesheet.util.DataManager");

hcm.approve.timesheet.util.DataManager = (function() {

	var _modelBase = null;
	var _resourceBundle = null;
	var _cachedModelObj = {};
	_cachedModelObj.exist = true;

	return {

		init: function(oDataModel, oresourceBundle) {
			_modelBase = oDataModel;
			_modelBase.setCountSupported(false);

			//_modelBase.setUseBatch(true);
			_resourceBundle = oresourceBundle;
		},

		getBaseODataModel: function() {
			return _modelBase;
		},

		setCachedModelObjProp: function(propName, propObj) {
			_cachedModelObj[propName] = propObj;
		},

		getCachedModelObjProp: function(propName) {
			return _cachedModelObj[propName];
		},

		getMaster: function(successCallback, errorCallback) {
			var sPath = "TIME_PENDING";
			var mParameters = {
				// urlParameters : "TIME_PENDING",
				async: false,
				success: jQuery.proxy(function(objResponse) {
					successCallback(objResponse.results);
				}, this),
				error: function(objResponse) {
					errorCallback(objResponse);
				}
			};
			_modelBase.read(sPath, mParameters);
		},

		getDetail: function(filter, successCallback, errorCallback) {
			var oFilter = {
				"$filter": filter
			};
			var sPath = "TIME_DETAILS_EMP";
			var mParameters = {
				urlParameters: oFilter,
				async: true,
				success: jQuery.proxy(function(objResponse) {
					successCallback(objResponse.results);
				}, this),
				error: function(objResponse) {
					errorCallback(objResponse);
				}
			};
			_modelBase.read(sPath, mParameters);
		},

		getRejectionReasons: function(successCallback, errorCallback) {
			var sPath = "REJ_REASON";
			var mParameters = {
				async: false,
				success: jQuery.proxy(function(objResponse) {
					this.setCachedModelObjProp("RejectionReason", objResponse.results);
					successCallback(objResponse.results);
				}, this),
				error: function(objResponse) {
					errorCallback(objResponse);
				}
			};
			_modelBase.read(sPath, mParameters);
		},

		submitPendingEntries: function(collection, successCallback) {
			var onRequestFailed = function(oError) {
				this.processError(oError);
			};
			_modelBase.create(collection, null, null, jQuery.proxy(function(oData, oResponse) {
				successCallback(oData, oResponse);

				/*this.self.oRouter.navTo("master");*/
			}, this), jQuery.proxy(onRequestFailed, this));
		},

		processError: function(oError) {
			var errorObj = JSON.parse(oError.response.body).error;
			var errorSet = errorObj.innererror.errordetails;
			var finalMessage, messageSeverity, finalMessageSeverity;
			finalMessage = messageSeverity = "";
			finalMessageSeverity = errorSet[0].severity;
			var messageHeader = errorSet[0].message;

			for (var i = 0; i < errorSet.length; i++) {
				if (errorSet[i].code.match("/IWBEP")) {
					continue;
				}
				finalMessage += errorSet[i].message + "\n";
				messageSeverity = errorSet[i].severity;
				if (finalMessageSeverity !== "error" && finalMessageSeverity !== messageSeverity) {
					finalMessageSeverity = messageSeverity;
				}
			}

			sap.ca.ui.message.showMessageBox({
				type: (finalMessageSeverity === "error") ? sap.ca.ui.message.Type.ERROR : sap.ca.ui.message.Type.WARNING,
				message: messageHeader,
				details: finalMessage
			});

		}

	};

}());