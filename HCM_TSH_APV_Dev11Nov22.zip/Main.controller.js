/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("hcm.approve.timesheet.Main",{onInit:function(){jQuery.sap.require("sap.ca.scfld.md.Startup");sap.ca.scfld.md.Startup.init("hcm.approve.timesheet",this);jQuery.sap.require("hcm.approve.timesheet.util.DataManager");jQuery.sap.require("hcm.approve.timesheet.util.Formatter");}});
