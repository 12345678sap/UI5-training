/*global history */
sap.ui.define([
	"zsnotif/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"zsnotif/model/formatter"
], function(BaseController, JSONModel, History, Filter, FilterOperator, GroupHeaderListItem, Device, formatter) {
	"use strict";

	return BaseController.extend("zsnotif.controller.Master", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */

		onInit: function() {
			// Control state model
              var oModel1 = new sap.ui.model.json.JSONModel([]);sap.ui.getCore().setModel(oModel1,"StudyModel");    //Added By Deepthi FETR0013627
              var oModel2 = new sap.ui.model.json.JSONModel([]);sap.ui.getCore().setModel(oModel2,"ProjectModel");    //Added By Deepthi 
			var loginUserId = sap.ushell.Container.getService("UserInfo").getUser().getId();

			var oList = this.byId("list"),
				oViewModel = this._createViewModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();
			// ch01 for filter binding 
			this.userId = loginUserId;
			var oBindingInfo = {
				path: "/SNHeaderSet",
				template: this.byId("listTemp"),
				filters: [
					new sap.ui.model.Filter("Uname", sap.ui.model.FilterOperator.EQ, sap.ushell.Container.getService("UserInfo").getUser().getId())
				],
				//Sorters for not_SS
				sorters: [new sap.ui.model.Sorter("PurchNoC", false)]

			};

			oList.bindAggregation("items", oBindingInfo);
			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};

			/*var oData={StartDate: new Date()};
			  sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel(oData), "VM");*/
			this.setModel(oViewModel, "masterView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oList.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			this.getView().addEventDelegate({
				onBeforeFirstShow: function() {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);

			window.masterthis = this;
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * After list data is available, this handler method updates the
		 * master list counter and hides the pull to refresh control, if
		 * necessary.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
			// hide pull to refresh if necessary
			this.byId("pullToRefresh").hide();
			// this.oInitialLoadFinishedDeferred.resolve();
			var aItems = this._oList.getItems();
			if (aItems.length) {
				this._oList.setSelectedItem(aItems[0], true);
				this._showDetail(aItems[0]);
			} else {
				this.getRouter().navTo("detailNoObjectsAvailable", {}, true); //enhance_search
			}
		},

		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		//* For Seaching SN's by TextLine
		onSearch: function(oEvent) {
			/*	if (oEvent.getParameters().refreshButtonPressed) {
					// Search field's 'refresh' button has been pressed.
					// This is visible if you select any master list item.
					// In this case no new search is triggered, we only
					// refresh the list binding.
					this.onRefresh();
					return;
				}   */

			var sQuery = oEvent.getParameter("query");
			var that = this;
			var filters = [];
			if (sQuery) {
				filters = [new Filter("PurchNoC", FilterOperator.Contains, sQuery)];
				this._oList.getBinding("items").filter(filters);
			} else {
				this._oList.getBinding("items").filter(filters);
				that.onRefresh();
			}
		},

		/** Search project code/Recommendation Number using Search button */
		onPrjctSearch: function(oEvent) {
			var notifNum = this.byId("searchField").getValue();
			var projCode = this.byId("idSearchPrjct").getValue();
			var studyName = this.byId("idSearchStudyName").getValue(); //nag

			var oFunFilter = [];
			var bothFilters = [];
			// start of changes by nag
			if (notifNum && projCode && studyName) {
				oFunFilter.push(new sap.ui.model.Filter("FunctLoc", sap.ui.model.FilterOperator.EQ, projCode));
				oFunFilter.push(new sap.ui.model.Filter("PurchNoC", sap.ui.model.FilterOperator.EQ, notifNum));
				oFunFilter.push(new sap.ui.model.Filter("StudyName", sap.ui.model.FilterOperator.EQ, studyName));
				bothFilters.push(new sap.ui.model.Filter(oFunFilter, true));
				this._oList.getBinding("items").filter(bothFilters);
			} else if (notifNum && projCode) {
				oFunFilter.push(new sap.ui.model.Filter("FunctLoc", sap.ui.model.FilterOperator.EQ, projCode));
				oFunFilter.push(new sap.ui.model.Filter("PurchNoC", sap.ui.model.FilterOperator.EQ, notifNum));
				bothFilters.push(new sap.ui.model.Filter(oFunFilter, true));
				this._oList.getBinding("items").filter(bothFilters);
			} else if (notifNum && studyName) {
				oFunFilter.push(new sap.ui.model.Filter("PurchNoC", sap.ui.model.FilterOperator.EQ, notifNum));
				oFunFilter.push(new sap.ui.model.Filter("StudyName", sap.ui.model.FilterOperator.EQ, studyName));
				bothFilters.push(new sap.ui.model.Filter(oFunFilter, true));
				this._oList.getBinding("items").filter(bothFilters);
			} else if (projCode && studyName) {
				oFunFilter.push(new sap.ui.model.Filter("FunctLoc", sap.ui.model.FilterOperator.EQ, projCode));
				oFunFilter.push(new sap.ui.model.Filter("StudyName", sap.ui.model.FilterOperator.EQ, studyName));
				bothFilters.push(new sap.ui.model.Filter(oFunFilter, true));
				this._oList.getBinding("items").filter(bothFilters);
			} else if (projCode) {
				oFunFilter.push(new sap.ui.model.Filter("FunctLoc", sap.ui.model.FilterOperator.EQ, projCode));
				this._oList.getBinding("items").filter(oFunFilter);
			} else if (notifNum) {
				oFunFilter.push(new sap.ui.model.Filter("PurchNoC", sap.ui.model.FilterOperator.EQ, notifNum));
				this._oList.getBinding("items").filter(oFunFilter);
			} else if (studyName) {
				oFunFilter.push(new sap.ui.model.Filter("StudyName", sap.ui.model.FilterOperator.EQ, studyName));
				this._oList.getBinding("items").filter(oFunFilter);
			} else {
				this._oList.getBinding("items").filter(oFunFilter);
			}
			// end of changes by nag
		},

		/** Search Study code using F4help */
		onSearchStudyCodeValueHelp: function(oEvent) {
			this.StudyCodeDialog = sap.ui.xmlfragment("zsnotif.view.StudyCode", this);
			this.StudyCodeDialog.open();
			var that = this;
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var oMod = new sap.ui.model.odata.ODataModel(sServiceUrl);
			var readRequestURL = "/Study_F4Set/?$filter=Zcode eq 'STUDYDES'";
			//var readRequestURL = "/Project_F4Set/?$filter=Tplnr eq 'Func'";
			oMod.read(readRequestURL, null, null, false,
				function(StudyOData) {
					sap.ui.getCore().getModel("StudyModel").setData(StudyOData);                // Addded by Deepthi 
					var StudyModel =sap.ui.getCore().getModel("StudyModel");                    //  FETR0013627
					that.StudyCodeDialog.setModel(StudyModel, "StudyModel");                    // Addded by Deepthi 
				}
			);
		},

		_onStudyConfirm: function(oEvent) {
			//var selectedVal = oEvent.getParameters().selectedItem.getProperty("title");
			//this.byId("idSearchStudyName").setValue(selectedVal);

			if (oEvent.getParameters().selectedContexts) {                         //Added by Deepthi   FETR0013627
				var aContexts = oEvent.getParameters().selectedContexts;           //Added by Deepthi  FETR0013627

				if (aContexts && aContexts.length) {
					this.byId("idSearchStudyName").setValue(aContexts.map(function(oContext) {
						return sap.ui.getCore().getModel("StudyModel").getProperty(oContext.sPath).ZstudyDesc;     // Added by Deepthi  FETR0013627
					}).join("; "));
				}
			} else {
				var selectedVal = oEvent.getParameters().selectedItem.getProperty("title");
				this.byId("idSearchStudyName").setValue(selectedVal);
			}
			//this.StudyCodeDialog.destroy();
		},
		_onStudytCancel: function(oEvent) {
			//this.StudyCodeDialog.destroy();
		},
		_onStudySelect: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("Zcode", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter1 = new sap.ui.model.Filter("ZstudyDesc", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter2 = new sap.ui.model.Filter([oFilter, oFilter1], false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter2]);
		},

		/** Search project code using F4help */
		onSearchPrjctValueHelp: function(oEvent) {
			this.projectCodeDialog = sap.ui.xmlfragment("zsnotif.view.ProjectCode", this);
			this.projectCodeDialog.open();
			var that = this;
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var oMod = new sap.ui.model.odata.ODataModel(sServiceUrl);
			var readRequestURL = "/Project_F4Set/?$filter=Tplnr eq 'Func'";
			oMod.read(readRequestURL, null, null, false,
				 function(ProjectOData) {
				 	sap.ui.getCore().getModel("ProjectModel").setData(ProjectOData); 
				 	var ProjectModel = sap.ui.getCore().getModel("ProjectModel"); 
				 	that.projectCodeDialog.setModel(ProjectModel, "ProjectModel");
				 }
				// 	function(ProjectOData) {
				// 	var ProjectModel = new JSONModel();
				// 	ProjectModel.setData(ProjectOData);
				// 	that.projectCodeDialog.setModel(ProjectModel, "ProjectModel");
				// }
			);
		},
		_onProjectConfirm: function(oEvent) {
			 if (oEvent.getParameters().selectedContexts) {                                          //Added
			 	var aContexts = oEvent.getParameters().selectedContexts;                             //Added
				if (aContexts && aContexts.length) {
					this.byId("idSearchPrjct").setValue(aContexts.map(function(oContext) {
							return sap.ui.getCore().getModel("ProjectModel").getProperty(oContext.sPath).Tplnr;  //Added
					}).join("; "));
				}
				// 	if (oEvent.getParameters().selectedItems) {
				// var aContexts = oEvent.getParameters().selectedItems;
				// if (aContexts && aContexts.length) {
				// 	this.byId("idSearchPrjct").setValue(aContexts.map(function(oContext) {
				// 		return oContext.getProperty("title");
				// 	}).join("; "));
				// }
			} else {
				var selectedVal = oEvent.getParameters().selectedItem.getProperty("title");
				this.byId("idSearchPrjct").setValue(selectedVal);
			}
			this.projectCodeDialog.destroy();
		},
		_onProjectCancel: function(oEvent) {
			this.projectCodeDialog.destroy();
		},
		_onProjectSelect: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("Tplnr", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter1 = new sap.ui.model.Filter("Pltxt", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter2 = new sap.ui.model.Filter([oFilter, oFilter1], false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter2]);
		},
		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function(oEvent) {
			this._oList.getBinding("items").refresh();
			//	this.onSelectionChange();
		},

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange: function(oEvent) {
			// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
			this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		},

		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed: function() {
			this._oList.removeSelections(true);
		},

		/**
		 * Used to create GroupHeaders with non-capitalized caption.
		 * These headers are inserted into the master list to
		 * group the master list's items.
		 * @param {Object} oGroup group whose text is to be displayed
		 * @public
		 * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
		 */
		createGroupHeader: function(oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.text,
				upperCase: false
			});
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		_createViewModel: function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "PurchNoC",
				groupBy: "None"
			});
		},

		/**
		 * If the master route was hit (empty hash) we have to set
		 * the hash to to the first item in the list as soon as the
		 * listLoading is done and the first item in the list is known
		 * @private
		 */
		_onMasterMatched: function() {
			this.getOwnerComponent().oListSelector.oWhenListLoadingIsDone.then(
				function(mParams) {
					if (mParams.list.getMode() === "None") {
						return;
					}
					//mychange
					var sObjectId = mParams.firstListitem.getBindingContext().getProperty("NotifNum");

					this.getRouter().navTo("object", {
						objectId: sObjectId
					}, true);
				}.bind(this),
				function(mParams) {
					if (mParams.error) {
						return;
					}
					this.getRouter().getTargets().display("detailNoObjectsAvailable");
				}.bind(this)
			);
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail: function(oItem) {
			var bReplace = !Device.system.phone;
			//CH03 mychage 
			var sObjectId = oItem.getBindingContext().getProperty("Tasktype");
			//	var quotdate = oItem.getBindingContext().getProperty("Angdt");
			//	var RFQDispStatus = oItem.getBindingContext().getProperty("Zrfqdisst");

			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("NotifNum")
			}, bReplace);
		},

		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function(iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
				this.getModel("masterView").setProperty("/title", sTitle);
			}
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		_applyFilterSearch: function() {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},

		/**
		 * Internal helper method to apply both group and sort state together on the list binding
		 * @param {sap.ui.model.Sorter[]} aSorters an array of sorters
		 * @private
		 */
		_applyGroupSort: function(aSorters) {
			this._oList.getBinding("items").sort(aSorters);
		},

		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		_updateFilterBar: function(sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		},
		//Begin of  Sort  		
		onSortsettings: function(oEvent) {
			var Sortthis = this;
			// Open the Table Setting dialog
			if (!Sortthis._oDialog) {
				Sortthis._oDialog = sap.ui.xmlfragment("zsnotif.view.ViewSettingsDialog", Sortthis);
			}
			Sortthis._oDialog.open();

		},

		onSortconfirm: function(oEvent) {
			var oView = this.getView();
			var oList = oView.byId("list");
			var mParams = oEvent.getParameters();
			var oBinding = oList.getBinding("items");

			var aSorters = [];
			if (mParams.groupItem) {
				var sPath = mParams.groupItem.getKey();
				var bDescending = mParams.groupDescending;
				var vGroup = function(oContext) {
					var name = oContext.getProperty("PlandEndDate");
					return {
						key: name,
						text: name
					};
				};
				aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));

			}
			//apply sort
			var sPath = mParams.sortItem.getKey();
			var bDescending = mParams.sortDescending;
			aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
			oBinding.sort(aSorters);

		},

		//end 

		// Begin of Filter
		onFilterSettings: function(oEvent) {
			var fself = this;
			// Open the Table Setting dialog

			if (!fself._oDialog1) {
				fself._oDialog1 = sap.ui.xmlfragment("zsnotif.view.Filter", fself);
			}
			fself._oDialog1.open();
			//fself._oDialog1.destroy(true);
			var _self = this;
			var FilterData = _self.getView().getModel().oData;
			var Location_Desc_Data = [];
			var Filter_Project_Desc_Data = [];
			var Filter_Project_Desc = {};
			var Filter_Location_Desc = {};

			for (var i = 0; i < Object.keys(FilterData).length; i++) {
				var Filter_Project_Desc = {};
				var Filter_Location_Desc = {};
				Filter_Location_Desc.a = this.getView().getModel().oData[Object.keys(FilterData)[i]].FunctLoc;
				Filter_Location_Desc.b = this.getView().getModel().oData[Object.keys(FilterData)[i]].Funcldescr;
				Location_Desc_Data.push(Filter_Location_Desc);

			}
			var Loc_desc_Filter_AllData = [];
			var Loc_Desc_All_Data = [];
			var ty = [];
			for (var i = 0; i < Location_Desc_Data.length; i++) {

				if ($.inArray(Location_Desc_Data[i].a, Loc_desc_Filter_AllData) === -1) {
					var obj = {};
					obj.a1 = Location_Desc_Data[i].a;
					obj.b1 = Location_Desc_Data[i].b;

					Loc_desc_Filter_AllData.push(Location_Desc_Data[i].a);
					ty.push(obj);

					Loc_Desc_All_Data.push(Loc_desc_Filter_AllData);
				}

			}

			var Filter_array = [];

			for (var i = 0; i < ty.length; i++) {

				var Filter_LocDesc_object = {};
				Filter_LocDesc_object.FunctLoc = ty[i].a1;
				Filter_LocDesc_object.Funcldescr = ty[i].b1;
				Filter_array.push(Filter_LocDesc_object);
			}

			var Filter_model = new sap.ui.model.json.JSONModel();
			Filter_model.setData(Filter_array);
			this.getView().setModel(Filter_model, "SNfilteSet");

			sap.ui.getCore().byId("Filter_Loc_Desc").setModel(this.getView().getModel("SNfilteSet"), "SNfilteSet");
			var valueCheck = "2";
			//Task type. 	
			var FilterData1 = _self.getView().getModel().oData;

			var Location_Desc_Data1 = [];

			for (var i = 0; i < Object.keys(FilterData1).length; i++) {
				var Filter_Location_Desc1 = this.getView().getModel().oData[Object.keys(FilterData)[i]].Tasktype;

				Location_Desc_Data1.push(Filter_Location_Desc1);

			}

			var Loc_desc_Filter_AllData1 = [];
			var Loc_Desc_All_Data1 = [];
			$.each(Location_Desc_Data1, function(index, word) {
				if ($.inArray(word, Loc_desc_Filter_AllData1) === -1) {
					Loc_desc_Filter_AllData1.push(word);
					Loc_Desc_All_Data1.push(Loc_desc_Filter_AllData1);
				}
			});

			var Filter_array1 = [];

			for (var i = 0; i < Loc_desc_Filter_AllData1.length; i++) {

				var Filter_LocDesc_object1 = {};
				Filter_LocDesc_object1.Tasktype = Loc_desc_Filter_AllData1[i];
				Filter_array1.push(Filter_LocDesc_object1);
			}

			var Filter_model = new sap.ui.model.json.JSONModel();
			Filter_model.setData(Filter_array1);
			this.getView().setModel(Filter_model, "SNfilteSet1");

			sap.ui.getCore().byId("Filter_Tasktype_Desc").setModel(this.getView().getModel("SNfilteSet1"), "SNfilteSet1");

		},

		onFilterconfirm: function(oEvent) {
			var selft = this;
			var oView = this.getView();
			var oList = oView.byId("list");
			var mParams = oEvent.getParameters();
			var oBinding = oList.getBinding("items");
			////code for filter
			var aFilterItems = oEvent.getParameters().filterItems,
				aFilters = [],
				aCaptions = [];
			var _self = this;
			var FilterData = _self.getView().getModel().oData;
			var Location_Desc_Data = [];
			aFilterItems.forEach(function(oItem) {
				for (var i = 0; i < Object.keys(FilterData).length; i++) {
					if (oItem.getKey() === selft.getView().getModel().oData[Object.keys(FilterData)[i]].FunctLoc) {
						aFilters.push(new Filter("FunctLoc", FilterOperator.EQ, oItem.getKey()));
						aFilters.push(new Filter("Uname", FilterOperator.EQ, sap.ushell.Container.getService("UserInfo").getUser().getId()));
						aCaptions.push(oItem.getText());
					}
				}
			});
			if (aFilters !== "") {
				this._oList.getBinding("items").filter(aFilters);
			} else {
				this._oList.getBinding("items").filter();
			}
			aFilterItems.forEach(function(oItem) {
				for (var i = 0; i < Object.keys(FilterData).length; i++) {
					if (oItem.getKey() === selft.getView().getModel().oData[Object.keys(FilterData)[i]].Tasktype) {
						aFilters.push(new Filter("Tasktype", FilterOperator.EQ, oItem.getKey()));
						aCaptions.push(new Filter("Uname", FilterOperator.EQ, sap.ushell.Container.getService("UserInfo").getUser().getId()));
						aCaptions.push(oItem.getText());
					}
				}
			});
			// // due date 
			if (aFilters !== "") {
				this._oList.getBinding("items").filter(aFilters);
			} else {
				this._oList.getBinding("items").filter();
			}
			// Quote_end_dateid
			var sQueryDate = sap.ui.getCore().byId("idDuedate").getValue();
			if (sQueryDate !== "") {
				var splitDate = sQueryDate; //FilterDate;
				if (splitDate !== "") {
					var stest = splitDate;
					if (stest) {
						var filters = [new Filter("PlndEndDate", FilterOperator.LE, stest), new Filter("Uname", FilterOperator.EQ, sap.ushell.Container.getService(
							"UserInfo").getUser().getId())];
						this._oList.getBinding("items").filter(filters);
					} else {
						//	oBinding.filter();
						this._oList.getBinding("items").filter();
					}
				}
				sap.ui.getCore().byId("idDuedate").setValue("");
			}
		},
		//End  Of Filter 
		onSelect: function(oEvent) {
			sap.ui.getCore().byId("filterlist").getSelctedItem();
		},

		onDialogOkButton: function(oEvent) {

			// Open the Table Setting dialog

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("zsnotif.view.ViewSettingsDialog1", this);
			}
			this._oDialog.close();

		},

		_applyFilterSearch1: function() {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");

		},

		QuoteValDateValueChange: function(oevent) {

			this.getView().byId("Quote_end_dateid").setDisplayFormat("dd-MM-yyyy");
			this.getView().byId("Quote_end_dateid").setValueFormat("dd-MM-yyyy");

		},

		handleChange: function(oEvent) {
			var oText = this.getView().byId("idDuedate");
			var oDP = oEvent.getSource();
			var sValue = oEvent.getParameter("value");
			var bValid = oEvent.getParameter("valid");
			this._iEvent++;
			//	oText.setText("Change - Event " + this._iEvent + ": DatePicker " + oDP.getId() + ":" + sValue);

			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				oDP.setValueState(sap.ui.core.ValueState.Error);
			}
		},

		onExit: function(oEvent) {

			var f1self = this;
			// Open the Table Setting dialog

			if (!f1self._oDialog1) {

				f1self._oDialog1 = sap.ui.xmlfragment("zsnotif.view.Filter", f1self);
			}
			f1self._oDialog1.destroy(true);

		}

	});

});