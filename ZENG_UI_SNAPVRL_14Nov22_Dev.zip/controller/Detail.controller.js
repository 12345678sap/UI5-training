/*global location */
var flag;
var responseValue;
var statusId3;
var siteVerificationRole;
var deleteScroll;
var futureRole;
var uploadPress = false;
var deletePress = false;
//var newDoc = [];
sap.ui.define([
	"zsnotif/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"zsnotif/model/formatter",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/Text",
	"sap/m/TextArea",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, formatter, MessageToast, MessageBox) {
	"use strict";

	return BaseController.extend("zsnotif.controller.Detail", {

		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			//	var NotificNo = "300001626";

			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading")
			});

			this.dataObject = "";
			// detailThis = this;

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function() {
			var oViewModel = this.getModel("detailView");

			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("detailView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});

			oShareDialog.open();
		},

		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		onListUpdateFinished: function(oEvent) {
			var sTitle,
				iTotalItems = oEvent.getParameter("total"),
				oViewModel = this.getModel("detailView");
			if (flag) {
				this._onBindingChange(oEvent);
			}
			// only update the counter if the length is final
			if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
				} else {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
				}
				oViewModel.setProperty("/lineItemListTitle", sTitle);
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */

		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			if (flag) {
				sObjectId = oEvent.getParameter("arguments").objectId;
				this.ontempSave2(responseValue, sObjectId);
			} else {
				this.getModel().metadataLoaded().then(function() {
					var sObjectPath = this.getModel().createKey("SNHeaderSet", {
						NotifNum: sObjectId
					});
					this._bindView("/" + sObjectPath);
				}.bind(this));
			}
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");
			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},
		//For each  Event  for each SN's Change and Details set  
		_onBindingChange: function(oEvent) {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();
			this.saveFlag = false;
			this.errorFlag = false;
			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}
			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.NotifNum,
				// sObjectName = oObject.PurchNoC,
				oViewModel = this.getModel("detailView");
			this.sObjectId1 = sObjectId;
			this.SVActioneeChanged = false;
			this.SVFinalApproverChange = false;
			this.SVFinalApproverDueDateChange = false;
			this.SVApproverDueDateChange = false;
			this.SVDueDateChange = false;
			this.SVApproverChanged = false;
			this.changeBlank = false;

			// this.SVApproverChanged = false;
			// this.SVFApproverChanged = false;
			this.getView().byId("approverDueDateID").attachBrowserEvent('keydown', function(e) {
				var key = e.keyCode ? e.keyCode : e.which;
				if (!([8, 9, 13, 27, 46, 110].indexOf(key) !== -1 ||
						(key === 65 && (e.ctrlKey || e.metaKey)) ||
						(key >= 35 && key <= 40) ||
						(key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
						(key >= 96 && key <= 105)
					)) {
					e.preventDefault();
				}
			});
			this.getView().byId("finalApproverDueDateID").attachBrowserEvent('keydown', function(e) {
				var key = e.keyCode ? e.keyCode : e.which;
				if (!([8, 9, 13, 27, 46, 110].indexOf(key) !== -1 ||
						(key === 65 && (e.ctrlKey || e.metaKey)) ||
						(key >= 35 && key <= 40) ||
						(key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
						(key >= 96 && key <= 105)
					)) {
					e.preventDefault();
				}
			});
			this.getView().byId("sVActioneeID").setValue("");
			this.getView().byId("sVDueDate").setValue("");
			this.getView().byId("sVApproverID").setValue("");
			this.getView().byId("approverDueDateID").setValue("");
			this.getView().byId("sVFinalApproverID").setValue("");
			this.getView().byId("finalApproverDueDateID").setValue("");
			// SNNode  Deatails
			if (flag) {
				sObjectId = oEvent;
			}
			var urlServices = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var omodel = new sap.ui.model.odata.ODataModel(urlServices);
			var detailRequesturl = "/SNDetailSet('" + sObjectId +
				"')?$expand=SNDETAILTONODE,SNDETAILTOHISTORY,SNDETAILTOREFFILE,SNDETAILTOEDVFILE";
			var self = this;
			omodel.read(detailRequesturl, null,
				null,
				false,
				function(oData, oResponse) {
					// create JSON model
					var oODataJSONModelDetail = new sap.ui.model.json.JSONModel();
					var oODataJSONModel = new sap.ui.model.json.JSONModel();
					var oODataJSONModel1 = new sap.ui.model.json.JSONModel();
					var oODataJSONModelRF = new sap.ui.model.json.JSONModel();
					var oODataJSONModelEF = new sap.ui.model.json.JSONModel();
					var oODataJSONModelSVEF = new sap.ui.model.json.JSONModel();
					var oODataJSONModelCU = new sap.ui.model.json.JSONModel();
					var oODataJSONModelRM = new sap.ui.model.json.JSONModel();
					var systemDate = oData.Sydatum;
					var previousDate = systemDate.split("T")[0].split("-");
					self.getView().byId("sVDueDate").setMinDate(new Date(parseInt(previousDate[0]), parseInt(previousDate[1] - 1), parseInt(
						previousDate[2])));
					self.getView().byId("idCombo").setEnabled(true);
					self.getView().byId("ch1").setEnabled(true);
					self.getView().byId("ch2").setEnabled(false);
					futureRole = oData.Claprflag;
					for (var i = 0; i < oData.SNDETAILTONODE.results.length; i++) {
						oData.SNDETAILTONODE.results[i].nodevisibleState = true;
						oData.SNDETAILTONODE.results[i].gWrdvisibleState = true;
						oData.SNDETAILTONODE.results[i].DiviavisibleState = true;
						oData.SNDETAILTONODE.results[i].UrnumvisibleState = true;
						oData.SNDETAILTONODE.results[i].CondvisibleState = true;
						oData.SNDETAILTONODE.results[i].SfddvisibleState = true;
						if (oData.SNDETAILTONODE.results[i].Nodefulltxt === "") {
							oData.SNDETAILTONODE.results[i].nodevisibleState = false;
						}
						if (oData.SNDETAILTONODE.results[i].Gudwrdfulltxt === "") {
							oData.SNDETAILTONODE.results[i].gWrdvisibleState = false;
						}
						if (oData.SNDETAILTONODE.results[i].Deviafulltxt === "") {
							oData.SNDETAILTONODE.results[i].DiviavisibleState = false;
						}
						if (oData.SNDETAILTONODE.results[i].Urnumfulltxt === "") {
							oData.SNDETAILTONODE.results[i].UrnumvisibleState = false;
						}
						if (oData.SNDETAILTONODE.results[i].Conseqfulltxt === "") {
							oData.SNDETAILTONODE.results[i].ConvisibleState = false;
						}
						if (oData.SNDETAILTONODE.results[i].Safeguardfulltxt === "") {
							oData.SNDETAILTONODE.results[i].SfdvisibleState = false;
						}
					}
					if (deleteScroll !== "X") {
						self.getView().byId("oScroll").scrollTo(0, 0);
					}
					deleteScroll = "";
					// AIP Required and SiteVerification.
					siteVerificationRole = oData.PartnRole;
					var aipRequired = oData.CurStatus;
					var siteBox = oData.Sitx;
					var aipBox = oData.Aipx;

					// Show Site Verification Form
					if (siteVerificationRole !== "ZA") {
						self.getView().byId("siteVerificationPersonnel").setVisible(false);
					} else {
						self.getView().byId("siteVerificationPersonnel").setVisible(true);
						if (siteBox === "X") {
							self.getView().byId("sVActioneeID").setEnabled(true);
							self.getView().byId("sVDueDate").setEnabled(true);
							self.getView().byId("sVApproverID").setEnabled(true);
							self.getView().byId("approverDueDateID").setEnabled(true);
							self.getView().byId("sVFinalApproverID").setEnabled(true);
							self.getView().byId("finalApproverDueDateID").setEnabled(true);
							self.getView().byId("acceptStaus").setEnabled(true);
							self.getView().byId("lblNoteID").setVisible(true); //Submit Validation
						}
					}

					//Begin of Aip buton
					var ot1 = "";
					if (siteBox == "X") {
						ot1 = siteBox;
					}
					var op1 = "";
					if (aipBox == "X") {
						op1 = aipBox;
					}
					if ((siteVerificationRole === "ZA") || (siteVerificationRole === "ZC") || (siteVerificationRole === "ZD")) {
						if (ot1 == "X") {
							oData.OptEnable = ot1;
							oData.Required = "Required";
							self.getView().byId("ch1").setEnabled(true);
						} else {

							oData.OptEnable = ot1;
							oData.Required = "Required";
							self.getView().byId("ch1").setEnabled(true);
						}
					} else {
						if (ot1 == "X") {
							oData.OptEnable = ot1;
							oData.Required = "";
							self.getView().byId("ch1").setEnabled(false);
						} else {
							oData.OptEnable = ot1;
							oData.Required = "";
							self.getView().byId("ch1").setEnabled(false);
						}
					}
					///Updated on 19th Jan 2018 by Bharat Singh added ZE,ZX/////
					///Updated on 23rd Jan 2018 by Bharat Singh added ZF,ZG,ZH/////
					if (siteVerificationRole === "ZE" || siteVerificationRole === "ZF" || siteVerificationRole === "ZG" || siteVerificationRole ===
						"ZH" || siteVerificationRole === "ZX") {
						self.getView().byId("idCombo").setEnabled(false);
					}
					if (siteVerificationRole === "ZC" || siteVerificationRole === "ZD") {
						self.getView().byId("ch2").setEnabled(true);
					}
					if ((aipRequired === "HAPC") || (aipRequired === "HRAP") || (aipRequired === "HAAP") || (aipRequired === "CRRJ")) {
						if (op1 == "X") {
							oData.AIPEnable = op1;
							oData.Required1 = "Required";
						} else {
							oData.AIPEnable = op1;
							oData.Required1 = "Required";
						}
					} else {
						if (op1 == "X") {
							oData.AIPEnable = op1;
							oData.Required1 = "Required";
							self.getView().byId("ch2").setEnabled(false);
						} else {
							oData.AIPEnable = op1;
							oData.Required1 = "Required";
							self.getView().byId("ch2").setEnabled(false);
						}
					}
					if ((aipRequired === "SWIP") || (aipRequired === "SAPC") || (aipRequired === "SRAP" || aipRequired === "SRRJ") || (aipRequired ===
							"SAAP") || (aipRequired === "SARJ")) {
						self.getView().byId("idCombo").setEnabled(false);
						self.getView().byId("ch1").setEnabled(false);
						self.getView().byId("ch2").setEnabled(false);
					}
					if (oData.Remline === "") {
						self.getView().byId("LabelRemarks").setVisible(false);
						self.getView().byId("Remarks").setVisible(false);
					} else {
						self.getView().byId("LabelRemarks").setVisible(true);
						self.getView().byId("Remarks").setVisible(true);
					}
					oODataJSONModelDetail.setData(oData);
					oODataJSONModel.setData(oData.SNDETAILTONODE.results);
					oODataJSONModel1.setData(oData.SNDETAILTOHISTORY.results);
					oODataJSONModelRF.setData(oData.SNDETAILTOREFFILE.results);
					// to bifercate the current user file attachment based on partnerRole
					var i, currentuserModel = [],
						EvidenceFiles = [],
						siteVerificationEvidenceFiles = [];
					for (i = 0; i < oData.SNDETAILTOEDVFILE.results.length; i++) {
						if (oData.PartnRole === oData.SNDETAILTOEDVFILE.results[i].pfunction) {
							currentuserModel.push(oData.SNDETAILTOEDVFILE.results[i]);
						} else if (oData.SNDETAILTOEDVFILE.results[i].pfunction === "ZF" || oData.SNDETAILTOEDVFILE.results[i].pfunction === "ZG" ||
							oData.SNDETAILTOEDVFILE.results[i].pfunction === "ZH") {
							siteVerificationEvidenceFiles.push(oData.SNDETAILTOEDVFILE.results[i]);
						} else {
							EvidenceFiles.push(oData.SNDETAILTOEDVFILE.results[i]);
						}
					}
					for (i = 0; i < currentuserModel.length; i++) {
						currentuserModel[i].Counter = i + 1;
					}
					for (i = 0; i < EvidenceFiles.length; i++) {
						EvidenceFiles[i].Counter = i + 1;
					}
					for (i = 0; i < siteVerificationEvidenceFiles.length; i++) {
						siteVerificationEvidenceFiles[i].Counter = i + 1;
					}
					oODataJSONModelEF.setData(EvidenceFiles);
					oODataJSONModelCU.setData(currentuserModel);
					oODataJSONModelSVEF.setData(siteVerificationEvidenceFiles);
					var oRecmend = self.getView().byId("IdRecom");
					oRecmend.setModel(oODataJSONModelDetail, "localRecom");
					// evidence file for fiori other users upload files
					var EFile = self.getView().byId("idEvidence");
					EFile.setModel(oODataJSONModelEF, "localEF");
					if (EFile.getModel("localEF").oData.length === 0) {
						EFile.setVisible(false);
					} else {
						EFile.setVisible(true);
					}
					// Site Verification evidence file for fiori other users upload files
					var sVEFile = self.getView().byId("idSiteVerificationEvidence");
					sVEFile.setModel(oODataJSONModelSVEF, "localSVEF");
					if (sVEFile.getModel("localSVEF").oData.length === 0) {
						sVEFile.setVisible(false);
					} else {
						sVEFile.setVisible(true);
					}
					// current user uploaded file attachments
					var MyCureentuser = self.getView().byId("idMyCureentuser");
					MyCureentuser.setModel(oODataJSONModelCU, "currentuserModel");
					//current user attachment list visiable property
					if (MyCureentuser.getModel("currentuserModel").oData.length === 0) {
						MyCureentuser.setVisible(false);
					} else {
						MyCureentuser.setVisible(true);
					}
					var Remarks = self.getView().byId("Remarks");
					Remarks.setModel(oODataJSONModelDetail, "localRM");
					statusId3 = oData.CurStatus;
					oData.zdet1VisibleSate = true;
					oData.zdet2VisibleSate = true;
					oData.zdet3VisibleSate = true;
					if (oData.Zdetail1 == "") {
						oData.zdet1VisibleSate = false;
					}
					if (oData.Zdetail2 == "") {
						oData.zdet2VisibleSate = false;
					}
					if (oData.Zdetail3 == "") {
						oData.zdet3VisibleSate = false;
					}
					// for History 
					if (oData.SNDETAILTOHISTORY.results.length > 0) {
						var tempHistory = oData.SNDETAILTOHISTORY.results[0].Tdline;
						for (var hf = 1; hf < oData.SNDETAILTOHISTORY.results.length; hf++) {
							if (oData.SNDETAILTOHISTORY.results[hf].TdFormat === "*") {
								tempHistory = tempHistory + "\n" + oData.SNDETAILTOHISTORY.results[hf].Tdline;
							} else {
								tempHistory = tempHistory + " " + oData.SNDETAILTOHISTORY.results[hf].Tdline;
							}
						}
						self.getView().byId("History").setText(tempHistory + "\n");
					} else {
						tempHistory = "";
						self.getView().byId("History").setText(tempHistory);
					}
					self.getView().byId("fileUploader").setValue("");
					var oform = self.getView().byId("idheader");
					oform.setModel(oODataJSONModelDetail, "localform");
					var siteVerification = self.getView().byId("ch1");
					siteVerification.setModel(oODataJSONModelDetail, "siteVerification1");
					var aipch2 = self.getView().byId("ch2");
					aipch2.setModel(oODataJSONModelDetail, "AIPVerification1");
					var olistRF = self.getView().byId("localModelRF");
					olistRF.setModel(oODataJSONModelRF, "localModelRFd");
					if (olistRF.getModel("localModelRFd").oData.length === 0) {
						olistRF.setVisible(false);
					} else {
						olistRF.setVisible(true);
					}
					var zfile = self.getView().byId("idDeatil");
					zfile.setModel(oODataJSONModelDetail, "localDeatilz");
					var zphase = self.getView().byId("idZPhase");
					zphase.setModel(oODataJSONModelDetail, "localZPhase");
					// Category 
					var cobmobox = self.getView().byId("idCombo");
					var categroy = oData.Zcatdes;
					cobmobox.setValue(categroy);
					var olist = self.getView().byId("lineItemsList");
					olist.setModel(oODataJSONModel, "localModel");
					// Action Status  for AIP, Accept ,And Reject .
					var statusId = oData.CurStatus;
					if ((statusId === "HRAP" || statusId === "CRRJ")) {
						self.getView().byId("AIPStaus").setEnabled(true);
					} else {
						self.getView().byId("AIPStaus").setEnabled(false);
					}
					if (statusId) {
						self.getView().byId("acceptStaus").setEnabled(true);
					} else {
						self.getView().byId("acceptStaus").setEnabled(false);
					}
					var SV = oData.PartnRole;
					if ((SV === "ZA") || (SV === "ZB") || (SV === "ZF")) {
						self.getView().byId("ReturnStaus").setEnabled(false);
					} else {
						self.getView().byId("ReturnStaus").setEnabled(true);
					}
					if (oData.Userstatus.indexOf("AIP") >= 0) {
						self.getView().byId("ch2").setEnabled(false);
						self.getView().byId("AIPStaus").setEnabled(false);
					}
					if (siteVerificationRole === "ZA" && self.getView().byId("ch1").getSelected() === true) {
						self.getView().byId("acceptStaus").setEnabled(true); //Submit validation
					} else {
						self.getView().byId("acceptStaus").setEnabled(true);
					}
					self._hseLineSiteVerification(sObjectId);
				});
			this.getOwnerComponent().oListSelector.selectAListItem(sPath);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
		},

		_hseLineSiteVerification: function(sObjectId) {
			var urlServices = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var ohseLineModel = new sap.ui.model.odata.ODataModel(urlServices);
			var self = this;
			// My Response
			var requestUrl = "/SNActionSet?$filter=Notifnum eq '" + sObjectId + "'";
			ohseLineModel.read(requestUrl, null, null, false,
				function(data, response) {
					var t = data.results.length;
					var temp;
					sap.ui.core.BusyIndicator.hide(); //hse_refresh_issue
					if (t > 0) {
						self.getView().byId("sVActioneeID").setValue(data.results[0].SVActionee);
						self.getView().byId("sVDueDate").setValue(formatter.formatDate3(data.results[0].SVDueDate));
						self.getView().byId("sVApproverID").setValue(data.results[0].SVApprover);
						self.getView().byId("approverDueDateID").setValue(data.results[0].SVAppDate);
						self.getView().byId("sVFinalApproverID").setValue(data.results[0].SVFApprover);
						self.getView().byId("finalApproverDueDateID").setValue(data.results[0].SVFApprDate);
						if (siteVerificationRole === "ZA") {
							if ((self.getView().byId("sVActioneeID").getValue() === "" && self.getView()
									.byId("sVDueDate").getValue() === "" && self.getView().byId("sVApproverID").getValue() === "" && self.getView().byId(
										"approverDueDateID").getValue() === "")) {
								self.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
							} else {
								self.getView().byId("acceptStaus").setEnabled(true);
							}
						}
						if (siteVerificationRole === "ZF" || siteVerificationRole === "ZG" || siteVerificationRole === "ZH") {
							if (data.results[1].HseLine === "") {
								temp = data.results[1].HseLine;
							} else {
								temp = data.results[1].HseLine + "\n";
							}
							for (var hf = 2; hf < data.results.length; hf++) {
								temp = temp + data.results[hf].HseLine + "\n";
							}
							self.getView().byId("idHSeLine").setValue(temp);
						} else {
							if (data.results[0].HseLine === "") {
								temp = data.results[0].HseLine;
							} else {
								temp = data.results[0].HseLine + "\n";
							}
							for (var hf = 1; hf < data.results.length; hf++) {
								temp = temp + data.results[hf].HseLine + "\n";
							}
							self.getView().byId("idHSeLine").setValue(temp);
						}
					} else {
						self.getView().byId("idHSeLine").setValue("");
					}
				},
				function(erro) {
					sap.ui.core.BusyIndicator.hide(); //hse_refresh_issue
					self.getView().byId("idHSeLine").setValue("");
				}
			);
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");
			// oLineItemTable = this.byId("lineItemsList"),
			// iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/lineItemTableDelay", 0);

			// oLineItemTable.attachEventOnce("updateFinished", function() {
			// 	// Restore original busy indicator delay for line item table
			// 	oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
			// });

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},

		//* My Response values when text is  changed
		handleLiveChange: function(oEvent) {
			flag = true;
			responseValue = this.getView().byId("idHSeLine").getValue();
		},
		actioneeValueHelp: function(oEvent) {
			var PageData = {
				"Input": oEvent.getSource()
			};
			var pModel = new sap.ui.model.json.JSONModel();
			pModel.setData(PageData);
			this.getView().setModel(pModel, 'Properties');
			var self = this;
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var oMod = new sap.ui.model.odata.ODataModel(sServiceUrl);
			var readRequestURL = "/Search_HelpSet/?$filter=ZInput eq 'APPR'";
			oMod.read(readRequestURL, null, null, false,
				function(AssignedTOData) {
					AssignedTOData.results.unshift({
						BName: " ",
						FName: " ",
						LName: " ",
						ZInput: " "
					});
					var AssignedToModel = new JSONModel();
					AssignedToModel.setData(AssignedTOData);
					var _oActioneeDialog = self._getActioneeDialog();
					_oActioneeDialog.setModel(AssignedToModel, "AssignedToModel");
					self._oActioneeDialog.open();
				}
			);
		},
		/**
		 *function name : _getActioneeDialog
		 *Reason :  On click of Site Verification Actionee search help SiteVerificationActionee fragment gets Opened
		 *input parameters: null
		 *return: null*/
		_getActioneeDialog: function() {
			// create dialog via fragment factory
			this._oActioneeDialog = sap.ui.xmlfragment("zsnotif.view.SiteVerificationActionee", this);
			return this._oActioneeDialog;
		},

		/**
		 *function name : _handleValueHelpSearchSiteVerificationActionee
		 *Reason : Helps us to do search operation in SiteVerificationActionee Fragment.
		 *input parameters: oEvent
		 *return: null*/
		_handleValueHelpSearchSiteVerificationActionee: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("FName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter1 = new sap.ui.model.Filter("LName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter3 = new sap.ui.model.Filter("BName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter2 = new sap.ui.model.Filter([oFilter, oFilter1, oFilter3], false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter2]);
		},

		/**
		 *function name : onSelectDialogItemSiteVerificationActionee
		 *Reason : On select of particular value it get binded to the Site Verification Actionee field
		 * so that we can pass the vlaue at the backend at the time of save.
		 *input parameters: oEvent
		 *return: null*/
		onSelectDialogItemSiteVerificationActionee: function(oEvent) {
			var Properties = this.getView().getModel("Properties").getData();
			var InputBox = Properties.Input;
			InputBox.setValue(oEvent.getParameters().selectedItem.getProperty("title"));
			oEvent.getSource().getBinding("items").filter([]);
			if (oEvent.getParameters().selectedItem.getProperty("title") === " ") {
				this.getView().byId("acceptStaus").setEnabled(true);
				this.getView().byId("sVActioneeID").setValue("");
				this.getView().byId("sVDueDate").setValue("");
				this.getView().byId("sVApproverID").setValue("");
				this.getView().byId("approverDueDateID").setValue("");
				this.getView().byId("sVFinalApproverID").setValue("");
				this.getView().byId("finalApproverDueDateID").setValue("");
				this.SVActioneeChanged = "Changed";
				this.SVFinalApproverChange = false;
				this.SVFinalApproverDueDateChange = false;
				this.SVApproverDueDateChange = false;
				this.SVDueDateChange = false;
				this.SVApproverChanged = false;
			} else {
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
				this.SVActioneeChanged = true;
			}
		},

		/**
		 *function name : _handleValueHelpCloseSiteVerificationActionee
		 *Reason :  On click of cancel button it will destroy the SiteVerificationActionee fragment
		 *input parameters: null
		 *return: null*/
		_handleValueHelpCloseSiteVerificationActionee: function() {
			this._getActioneeDialog().destroy();

		},
		approverValueHelp: function(oEvent) {
			var PageData = {
				"Input": oEvent.getSource()
			};
			var pModel = new sap.ui.model.json.JSONModel();
			pModel.setData(PageData);
			this.getView().setModel(pModel, 'Properties');
			var self = this;
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var oMod = new sap.ui.model.odata.ODataModel(sServiceUrl);
			var readRequestURL = "/Search_HelpSet/?$filter=ZInput eq 'APPR'";
			oMod.read(readRequestURL, null, null, false,
				function(AssignedTOData) {
					AssignedTOData.results.unshift({
						BName: " ",
						FName: " ",
						LName: " ",
						ZInput: " "
					});
					var AssignedToModel = new JSONModel();
					AssignedToModel.setData(AssignedTOData);
					var _oApproverDialog = self._getApproverDialog();
					_oApproverDialog.setModel(AssignedToModel, "AssignedToModel");
					self._oApproverDialog.open();
				}
			);

		},
		/**
		 *function name : _getApproverDialog
		 *Reason :  On click of Site Verification Approver search help SiteVerificationApprover fragment gets Opened
		 *input parameters: null
		 *return: null*/
		_getApproverDialog: function() {
			// create dialog via fragment factory
			this._oApproverDialog = sap.ui.xmlfragment("zsnotif.view.SiteVerificationApprover", this);
			return this._oApproverDialog;
		},

		/**
		 *function name : _handleValueHelpSearchSiteVerificationApprover
		 *Reason : Helps us to do search operation in SiteVerificationApprover Fragment.
		 *input parameters: oEvent
		 *return: null*/
		_handleValueHelpSearchSiteVerificationApprover: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("FName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter1 = new sap.ui.model.Filter("LName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter3 = new sap.ui.model.Filter("BName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter2 = new sap.ui.model.Filter([oFilter, oFilter1, oFilter3], false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter2]);
		},

		/**
		 *function name : onSelectDialogItemSiteVerificationApprover
		 *Reason : On select of particular value it get binded to the Site Verification Actionee field
		 * so that we can pass the vlaue at the backend at the time of save.
		 *input parameters: oEvent
		 *return: null*/
		onSelectDialogItemSiteVerificationApprover: function(oEvent) {
			var Properties = this.getView().getModel("Properties").getData();
			/*	if (this.getView().byId("sVActioneeID").getValue() === "") {
					sap.m.MessageToast.show("Site Verification Actionee cannot be blank");
				} else if (this.getView().byId("sVDueDate").getValue() === "") {
					sap.m.MessageToast.show("Site Verification Due Date cannot be blank");
				} else 
			if (this.getView().byId("sVActioneeID").getValue() === oEvent.getParameters().selectedItem.getProperty("title")) {
				sap.m.MessageToast.show("Approver cannot be same as Actionee");
			} else */ //Submit Validations
			if (oEvent.getParameters().selectedItem.getProperty("title") === " ") {
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
				this.getView().byId("sVApproverID").setValue("");
				this.getView().byId("approverDueDateID").setValue("");
				this.getView().byId("sVFinalApproverID").setValue("");
				this.getView().byId("finalApproverDueDateID").setValue("");
				this.SVApproverChanged = true;
			} else {
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
				var InputBox = Properties.Input;
				InputBox.setValue(oEvent.getParameters().selectedItem.getProperty("title"));
				oEvent.getSource().getBinding("items").filter([]);
				this.SVApproverChanged = true;
			}
		},
		sVDueDateChange: function(oEvent) {
			if (this.getView().byId("sVActioneeID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Actionee cannot be blank");
				this.getView().byId("sVDueDate").setValue("");
			} else if (this.getView().byId("sVDueDate").getValue() === "") {
				this.SVDueDateChange = true;
				this.getView().byId("acceptStaus").setEnabled(true);
			} else {
				this.SVDueDateChange = true;
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
			}
		},
		approverValueChange: function(oEvent) {
			if (this.getView().byId("sVActioneeID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Actionee cannot be blank");
				this.getView().byId("approverDueDateID").setValue("");
			} else if (this.getView().byId("sVDueDate").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Due Date cannot be blank");
				this.getView().byId("approverDueDateID").setValue("");
			} else if (this.getView().byId("sVApproverID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Approver cannot be blank");
				this.getView().byId("approverDueDateID").setValue("");
			} else if (this.getView().byId("approverDueDateID").getValue() === "") {
				this.SVApproverDueDateChange = true;
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
			} else {
				this.SVApproverDueDateChange = true;
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
			}
		},
		finalApproverValueChange: function(oEvent) {
			if (this.getView().byId("sVActioneeID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Actionee cannot be blank");
				this.getView().byId("finalApproverDueDateID").setValue("");
			} else if (this.getView().byId("sVDueDate").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Due Date cannot be blank");
				this.getView().byId("finalApproverDueDateID").setValue("");
			} else if (this.getView().byId("sVApproverID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Approver cannot be blank");
				this.getView().byId("finalApproverDueDateID").setValue("");
			} else if (this.getView().byId("approverDueDateID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Approver days cannot be blank");
				this.getView().byId("finalApproverDueDateID").setValue("");
			} else if (this.getView().byId("sVFinalApproverID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Final Approver cannot be blank");
				this.getView().byId("finalApproverDueDateID").setValue("");
			} else if (this.getView().byId("finalApproverDueDateID").getValue() === "") {
				this.SVFinalApproverDueDateChange = true;
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
			} else {
				this.SVFinalApproverDueDateChange = true;
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
			}
		},

		/**
		 *function name : _handleValueHelpCloseSiteVerificationApprover
		 *Reason :  On click of cancel button it will destroy the SiteVerificationApprover fragment
		 *input parameters: null
		 *return: null*/
		_handleValueHelpCloseSiteVerificationApprover: function() {
			this._getApproverDialog().destroy();
		},
		finalApproverValueHelp: function(oEvent) {
			var PageData = {
				"Input": oEvent.getSource()
			};
			//	columnNo = oEvent.getSource().getParent().getCustomData()[0].getProperty("value") - 2;
			var pModel = new sap.ui.model.json.JSONModel();
			pModel.setData(PageData);
			this.getView().setModel(pModel, 'Properties');
			var self = this;
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var oMod = new sap.ui.model.odata.ODataModel(sServiceUrl);
			var readRequestURL = "/Search_HelpSet/?$filter=ZInput eq 'APPR'";
			oMod.read(readRequestURL, null, null, false,
				function(AssignedTOData) {
					AssignedTOData.results.unshift({
						BName: " ",
						FName: " ",
						LName: " ",
						ZInput: " "
					});
					var AssignedToModel = new JSONModel();
					AssignedToModel.setData(AssignedTOData);
					var _oFinalApproverDialog = self._getFinalApproverDialog();
					_oFinalApproverDialog.setModel(AssignedToModel, "AssignedToModel");
					self._oFinalApproverDialog.open();
				}
			);
		},
		/**
		 *function name : _getApproverDialog
		 *Reason :  On click of Site Verification Final Approver search help SiteVerificationFinalApprover fragment gets Opened
		 *input parameters: null
		 *return: null*/
		_getFinalApproverDialog: function() {
			// create dialog via fragment factory
			this._oFinalApproverDialog = sap.ui.xmlfragment("zsnotif.view.SiteVerificationFinalApprover", this);
			return this._oFinalApproverDialog;
		},

		/**
		 *function name : _handleValueHelpSearchSiteVerificationFinalApprover
		 *Reason : Helps us to do search operation in SiteVerificationFinalApprover Fragment.
		 *input parameters: oEvent
		 *return: null*/
		_handleValueHelpSearchSiteVerificationFinalApprover: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("FName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter1 = new sap.ui.model.Filter("LName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter3 = new sap.ui.model.Filter("BName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter2 = new sap.ui.model.Filter([oFilter, oFilter1, oFilter3], false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter2]);
		},

		/**
		 *function name : onSelectDialogItemSiteVerificationFinalApprover
		 *Reason : On select of particular value it get binded to the Site Verification Final Approver field
		 * so that we can pass the vlaue at the backend at the time of save.
		 *input parameters: oEvent
		 *return: null*/
		onSelectDialogItemSiteVerificationFinalApprover: function(oEvent) {
			var Properties = this.getView().getModel("Properties").getData();
			/*if (this.getView().byId("sVActioneeID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Actionee cannot be blank");
			} else if (this.getView().byId("sVDueDate").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Due Date cannot be blank");
			} else if (this.getView().byId("sVApproverID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Approver cannot be blank");
			} else if (this.getView().byId("approverDueDateID").getValue() === "") {
				sap.m.MessageToast.show("Site Verification Approver Due Date cannot be blank");
			} else if (this.getView().byId("sVActioneeID").getValue() === oEvent.getParameters().selectedItem.getProperty("title")) {
				sap.m.MessageToast.show("Approver cannot be same");
			} else if (this.getView().byId("sVApproverID").getValue() === oEvent.getParameters().selectedItem.getProperty("title")) {
				sap.m.MessageToast.show("Approver cannot be same");
			} else*/ //Submit Validation
			if (oEvent.getParameters().selectedItem.getProperty("title") === " ") {
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
				this.getView().byId("sVFinalApproverID").setValue("");
				this.getView().byId("finalApproverDueDateID").setValue("");
				this.SVFinalApproverChange = true;
				this.changeBlank = true;
			} else {
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
				var InputBox = Properties.Input;
				InputBox.setValue(oEvent.getParameters().selectedItem.getProperty("title"));
				oEvent.getSource().getBinding("items").filter([]);
				this.SVFinalApproverChange = true;
			}
		},

		/**
		 *function name : _handleValueHelpCloseSiteVerificationFinalApprover
		 *Reason :  On click of cancel button it will destroy the SiteVerificationFinalApprover fragment
		 *input parameters: null
		 *return: null*/
		_handleValueHelpCloseSiteVerificationFinalApprover: function() {
			this._getFinalApproverDialog().destroy();
		},
		//* For poping  up of SaveDraft	for Each SN's when myResponse is changed. 
		ontempSave2: function(oitem, sObjectId2) {
			var sself = this;
			var siteVarif = "";
			flag = false;
			if (sself.getView().byId("ch1").getSelected() == true) {
				siteVarif = "X";
			}
			var AipReqir = "";
			if (sself.getView().byId("ch2").getSelected() == true) {
				AipReqir = "X";
			}
			var Zcategory1 = sself.getView().byId("idCombo").getValue(); //sself.getView().byId("idCombo").getSelectedItem().getText();
			var Zcategory = "";
			var Zcategory = "";
			var combodata = ["Implemented as recommended", "Alternate solution with justification", "Recommendation not followed with reason",
				" "
			];
			if (Zcategory1 == combodata[0]) {
				Zcategory = "1";
			} else if (Zcategory1 == combodata[1]) {
				Zcategory = "2";
			} else if (Zcategory1 == combodata[2]) {
				Zcategory = "3";
			} else if (Zcategory1 == combodata[3]) {
				Zcategory = "0";
			}
			var oViewModel = this.getModel("detailView");
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var sObjectId = this.getView().byId("idNotif").getText();
			var finalData = {};
			var NotifNum = sObjectId;
			var HseLine = oitem;
			var dself = this;
			var valuecheck = 0;
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			finalData.Uname = sap.ushell.Container.getService("UserInfo").getUser().getId();
			var action = "S";
			finalData.Notifnum = NotifNum;
			finalData.HseLine = HseLine;
			//finalData.Uname = name;
			finalData.Action = action;
			finalData.Sitx = siteVarif;
			finalData.Aipx = AipReqir;
			finalData.Zcat = Zcategory;
			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				content: new sap.m.Text({
					text: 'Do you want to save My Response text?'
				}),
				beginButton: new sap.m.Button({
					text: 'Yes',
					press: function() {
						if (HseLine !== "") {
							sap.ui.core.BusyIndicator.show(0);
							setTimeout(function() {
								oModel.create("/SNActionSet", finalData, {
									method: "POST",
									success: function(data, response) {
										flag = true;
										dself._onBindingChange(sObjectId2);
										sap.m.MessageToast.show("Data Saved");
										flag = false;
									},
									error: function(oEvent) {
										var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
										var msgLength = oMessageBox.length;
										var oMessage;
										if (msgLength === 0) {
											oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
										} else {
											oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
											if (msgLength > 0) {
												for (var msgRow = 1; msgRow < msgLength; msgRow++) {
													oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[msgRow].message;
												}
											}
										}
										sap.m.MessageBox.error(oMessage);
									}
								});
								sap.ui.core.BusyIndicator.hide();
							});
						}
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: 'No',
					press: function() {
						flag = true;
						dself._onBindingChange(sObjectId);
						sap.m.MessageToast.show("Data will not be saved");
						flag = false;
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
			return this.getView().byId("idNotif").getText();
		},
		//* Pop up for Saving the MyResponse Value. 
		onSaveForDrapt: function(oEvent) {
			var sself = this;
			var siteVarif = "";
			if (sself.getView().byId("ch1").getSelected() === true) {
				siteVarif = "X";
			}
			var aipReqir = "";
			if (sself.getView().byId("ch2").getSelected() === true) {
				aipReqir = "X";
			}
			var zcategory1 = sself.getView().byId("idCombo").getValue(); //getSelectedItem().getText();
			var zcategory = "";

			var combodata = ["Implemented as recommended", "Alternate solution with justification", "Recommendation not followed with reason",
				" "
			];
			if (zcategory1 === combodata[0]) {
				zcategory = "1";
			} else if (zcategory1 === combodata[1]) {
				zcategory = "2";
			} else if (zcategory1 === combodata[2]) {
				zcategory = "3";
			} else if (zcategory1 === combodata[3]) {
				zcategory = "0";
			}
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var sObjectId = this.getView().byId("idNotif").getText(); //"300001679";                         
			var finalData = {};
			var NotifNum = sObjectId;
			var hseLine = this.getView().byId("idHSeLine").getValue();
			var dself = this;
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			finalData.HseLine = hseLine;
			finalData.Uname = sap.ushell.Container.getService("UserInfo").getUser().getId();
			var action = "S";
			finalData.Notifnum = NotifNum;
			finalData.HseLine = hseLine;
			finalData.Action = action;
			finalData.Sitx = siteVarif;
			finalData.Aipx = aipReqir;
			finalData.Zcat = zcategory;
			finalData.SVActionee = "X";
			if (siteVerificationRole === "ZA" && uploadPress === false && deletePress === false) {
				if (siteVarif === "X" || dself.SVActioneeChanged === true || dself.SVDueDateChange === true || dself.SVApproverChanged === true ||
					dself.SVApproverDueDateChange ===
					true || dself.SVFinalApproverChange === true || dself.SVFinalApproverDueDateChange === true) {
					/*if (dself.getView().byId("sVActioneeID").getValue() === "") {
						sap.m.MessageBox.error("Site Verification Actionee cannot be blank");
						dself.errorFlag = true;
					} else if (dself.getView().byId("sVDueDate").getValue() === "") {
						sap.m.MessageBox.error("Site Verification Due Date cannot be blank");
						dself.errorFlag = true;
					} else if (dself.getView().byId("sVApproverID").getValue() === "") {
						sap.m.MessageBox.error("Site Verification Approver cannot be blank");
						dself.errorFlag = true;
					} else if (dself.getView().byId("approverDueDateID").getValue() === "") {
						sap.m.MessageBox.error("Site Verification Approver days cannot be blank");
						dself.errorFlag = true;
					} */
					if (dself.SVFinalApproverChange === true || dself.SVFinalApproverDueDateChange === true) {
						if (this.changeBlank === true) {
							dself.siteVerificationData(finalData);
						}
						/*else if (dself.getView().byId("sVFinalApproverID").getValue() === "") {
							sap.m.MessageBox.error("Site Verification Final Approver cannot be blank");
							dself.errorFlag = true;
						} 
						else if (dself.getView().byId("finalApproverDueDateID").getValue() === "") {
							sap.m.MessageBox.error("Site Verification Final Approver Due Date cannot be blank");
							dself.errorFlag = true;
						} */
						else {
							dself.siteVerificationData(finalData);
						}
					} else {
						dself.siteVerificationData(finalData);
					}
				} else if (dself.SVActioneeChanged === "Changed") {
					finalData.SVActionee = "";
					finalData.SVDueDate = null;
					finalData.SVApprover = "";
					finalData.SVAppDate = "";
					finalData.SVFApprover = "";
					finalData.SVFApprDate = "";
					dself.errorFlag = false;
				} else {
					finalData.SVActionee = "X";
					finalData.SVDueDate = null;
					finalData.SVApprover = "";
					finalData.SVAppDate = "";
					finalData.SVFApprover = "";
					finalData.SVFApprDate = "";
					dself.errorFlag = false;
				}
			}
			if (!sself.saveFlag && sself.errorFlag !== true) {
				var dialog = new sap.m.Dialog({
					title: 'Confirm',
					type: 'Message',
					content: new sap.m.Text({
						text: 'Are you sure you want to Save Draft?'
					}),
					beginButton: new sap.m.Button({
						text: "Confirmed",
						press: function() {
							if (hseLine !== "" || hseLine === "") {
								sap.ui.core.BusyIndicator.show(0);
								setTimeout(function() {
									oModel.create("/SNActionSet", finalData, {
										method: "POST",
										success: function(data, response) {
											flag = false;
											dself.SVActioneeChanged = false;
											uploadPress = false;
											deletePress = false;
											sap.m.MessageToast.show("Notification is Saved");
											dself.getView().byId("acceptStaus").setEnabled(true);
										},
										error: function(oEvent) {
											var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
											var msgLength = oMessageBox.length;
											var oMessage;
											if (msgLength === 0) {
												oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
											} else {
												oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
												if (msgLength > 0) {
													for (var msgRow = 1; msgRow < msgLength; msgRow++) {
														oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[msgRow].message;
													}
												}
											}
											sap.m.MessageBox.error(oMessage);

										}
									});
									sap.ui.core.BusyIndicator.hide();
								});
							}
							dialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			} else if (sself.errorFlag !== true) {
				if (hseLine !== "" || hseLine === "") {
					sap.ui.core.BusyIndicator.show(0);
					setTimeout(function() {
						oModel.create("/SNActionSet", finalData, {
							method: "POST",
							success: function(data, response) {
								flag = false;
								uploadPress = false;
								deletePress = false;
								sap.m.MessageToast.show("Notification is Saved");
							},
							error: function(oEvent) {
								var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
								var msgLength = oMessageBox.length;
								if (msgLength === 0) {
									var oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
								} else {
									var oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
									if (msgLength > 0) {
										for (var msgRow = 1; msgRow < msgLength; msgRow++) {
											oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[msgRow].message;
										}
									}
								}
								sap.m.MessageBox.error(oMessage);
							}
						});
						sap.ui.core.BusyIndicator.hide();
					});
				}
			}
		},

		//*  Actions for  Reject/Retrun when user wants to reject the perticular SN's 
		onReturn: function() {
			var action = "R";
			var siteVarif = "";
			var A1self = this;
			if (A1self.getView().byId("ch1").getSelected() == true) {
				siteVarif = "X";
			}
			var aipReqir = "";
			if (A1self.getView().byId("ch2").getSelected() == true) {
				aipReqir = "X";
			}
			var zcategory1 = A1self.getView().byId("idCombo").getValue(); //getSelectedItem().getText();
			var zcategory = "";
			var zcategory = "";
			var combodata = ["Implemented as recommended", "Alternate solution with justification", "Recommendation not followed with reason",
				""
			];
			if (zcategory1 == combodata[0]) {
				zcategory = "1";
			} else if (zcategory1 == combodata[1]) {
				zcategory = "2";
			} else if (zcategory1 == combodata[2]) {
				zcategory = "3";
			} else if (zcategory1 == combodata[3]) {
				zcategory = "0";
			}
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var sObjectId = this.getView().byId("idNotif").getText(); //"300001679";                         
			var finalData = {};
			var notifNum = sObjectId;
			var hseLine = this.getView().byId("idHSeLine").getValue();
			var Aself = this;
			var valuecheck = 0;
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			finalData.Notifnum = notifNum;
			finalData.HseLine = hseLine;
			finalData.Uname = sap.ushell.Container.getService("UserInfo").getUser().getId();
			finalData.Action = action;
			finalData.Zcat = zcategory;
			finalData.Aipx = aipReqir;
			finalData.Sitx = siteVarif;
			// var initialAttachments = "";
			// if (newDoc.length !== 0) {
			// 	initialAttachments = newDoc[0];
			// 	for (var newDocLength = 1; newDocLength < newDoc.length; newDocLength++) {
			// 		initialAttachments = initialAttachments + ";" + newDoc[newDocLength];
			// 	}
			// }
			// finalData.Attachments = initialAttachments;
			var Action = "R";
			var finalData = {};
			var oViewModel = this.getModel("detailView");
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			//passlogin user 
			var suname = sap.ushell.Container.getService("UserInfo").getUser().getId();
			var Requesturl = "/SNActionSet(Action='" + Action + "',Notifnum='" + sObjectId + "',Uname='" + suname + "',Sitx='" + siteVarif +
				"',Aipx='" + aipReqir + "',Zcat='" + zcategory + "')";
			var returnMessage = 'Would you like to return to Actionee?';
			if (this.getView().byId("idheader").getModel("localform").getData().Userstatus.indexOf("AIP") !== -1) {
				returnMessage = 'Would you like to return to AIP-Actionee?';
			}
			//ss_Added ZX-external client_FETR0014466
			if (siteVerificationRole === "ZE" || siteVerificationRole === "ZX") {
				returnMessage = 'Would you like to return to Approver?';
			} else if (siteVerificationRole === "ZH" || siteVerificationRole === "ZG") {
				returnMessage = 'Would you like to return to Site Actionee?';
			}

			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				content: new sap.m.Text({
					text: returnMessage
				}),
				beginButton: new sap.m.Button({
					text: 'Submit',
					press: function() {
						var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
						finalData.Notifnum = notifNum;
						finalData.HseLine = hseLine;
						finalData.Uname = sap.ushell.Container.getService("UserInfo").getUser().getId();
						finalData.Action = action;
						finalData.Zcat = zcategory;
						finalData.Aipx = aipReqir;
						finalData.Sitx = siteVarif;
						var sObjectId = Aself.getView().byId("idNotif").getText();
						var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
						//var testuser = sap.ushell.Container.getService("UserInfo").getUser().getId();
						//passlogin user 
						//	var Requesturl = "/SNActionSet(Action='" + Action + "',Notifnum='" + sObjectId + "',Uname='" + suname + "' )";
						var Requesturl = "/SNActionSet(Action='" + Action + "',Notifnum='" + sObjectId + "',Uname='" + suname + "',Sitx='" +
							siteVarif + "',Aipx='" + aipReqir + "',Zcat='" + zcategory + "')";
						sap.ui.core.BusyIndicator.show(0);
						setTimeout(function() {
							oModel.read(Requesturl, null,
								null,
								false,
								function(data, response) {
									if (data.EFlag !== "1") {
										if ((data.MsgType == "S") || (data.ReturnCode == "0")) {
											sap.m.MessageToast.show("Submission in Progress");
											if (hseLine !== "" || hseLine === "") {
												sap.ui.core.BusyIndicator.show(0);
												setTimeout(function() {
													oModel.create("/SNActionSet", finalData, {
														method: "POST",
														success: function(data, response) {
															flag = false;
															//	newDoc = [];
															//	sap.m.MessageToast.show(" Your  Response is Saved ");
														},
														error: function(oEvent) {
															var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
															var msgLength = oMessageBox.length;
															var oMessage;
															if (msgLength === 0) {
																oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
															} else {
																oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
																if (msgLength > 0) {
																	for (var msgRow = 1; msgRow < msgLength; msgRow++) {
																		oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[
																			msgRow].message;
																	}
																}
															}
															sap.m.MessageBox.error(oMessage);
															// if (hseLine === "") {
															//	sap.m.MessageToast.show("Please Enter  My Response ");
															// }
														}
													});
													sap.ui.core.BusyIndicator.hide();
												});
											}
											masterthis.getView().byId("list").getBinding("items").refresh();
											//	sap.ui.core.routing.HashChanger.getInstance().replaceHash("");
											//	masterthis.onInit();
											Aself._onBindingChange();
											flag = false;
										} else {
											sap.m.MessageToast.show("Notification Rejection failed");
										}
									} else {
										sap.m.MessageBox.error("Please Unlock " + sObjectId + " and reprocess again");
									}
								},
								function(oEvent) {
									var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
									var msgLength = oMessageBox.length;
									var oMessage;
									if (msgLength === 0) {
										oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
									} else {
										oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
										if (msgLength > 0) {
											for (var msgRow = 1; msgRow < msgLength; msgRow++) {
												oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[msgRow].message;
											}
										}
									}
									sap.m.MessageBox.error(oMessage);
								});
						});
						sap.ui.core.BusyIndicator.hide();
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		handleSelect: function() {
			var checked = this.getView().byId("ch1").getSelected();
			if (siteVerificationRole === "ZA" && checked === true) {
				this.getView().byId("sVActioneeID").setEnabled(true);
				this.getView().byId("sVDueDate").setEnabled(true);
				this.getView().byId("sVApproverID").setEnabled(true);
				this.getView().byId("approverDueDateID").setEnabled(true);
				this.getView().byId("sVFinalApproverID").setEnabled(true);
				this.getView().byId("finalApproverDueDateID").setEnabled(true);
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
				this.getView().byId("lblNoteID").setVisible(true); //Submit Validation
			} else if (siteVerificationRole === "ZA") {
				this.getView().byId("lblNoteID").setVisible(false);
				this.getView().byId("acceptStaus").setEnabled(true); //Submit Validation
				this.getView().byId("sVActioneeID").setValue("");
				this.getView().byId("sVDueDate").setValue("");
				this.getView().byId("sVApproverID").setValue("");
				this.getView().byId("approverDueDateID").setValue("");
				this.getView().byId("sVFinalApproverID").setValue("");
				this.getView().byId("finalApproverDueDateID").setValue("");
				this.getView().byId("sVActioneeID").setEnabled(false);
				this.getView().byId("sVDueDate").setEnabled(false);
				this.getView().byId("sVApproverID").setEnabled(false);
				this.getView().byId("approverDueDateID").setEnabled(false);
				this.getView().byId("sVFinalApproverID").setEnabled(false);
				this.getView().byId("finalApproverDueDateID").setEnabled(false);
				this.SVActioneeChanged = "Changed";
				this.SVFinalApproverChange = false;
				this.SVFinalApproverDueDateChange = false;
				this.SVApproverDueDateChange = false;
				this.SVDueDateChange = false;
				this.SVApproverChanged = false;
			} else {
				this.getView().byId("acceptStaus").setEnabled(true);
			}
		},

		//*	Actions for  Accept/submit when user wants to reject the perticular SN's
		onAccept: function() {
			var A1self = this;
			var aprovewarning = sap.ui.core.ValueState.None;
			var ApproveText = "Do you want to submit response?";
			var Approvetitle = "Confirm";
			var visibility = true; //Submit Validation
			if ((A1self.getView().byId("ch2").getSelected() === true) && (statusId3 === "HRAP")) {
				ApproveText = "Are you sure AIP is not required?";
				Approvetitle = "Warning";
				aprovewarning = sap.ui.core.ValueState.Warning;
				visibility = true; //Submit Validation
			}
			if (siteVerificationRole === "ZA") {
				if (A1self.getView().byId("ch1").getSelected() === true) {
					//Submit Validation - Start

					var AActionee = A1self.getView().byId("sVActioneeID").getValue();
					var DueDate = A1self.getView().byId("sVDueDate").getValue();
					var ApproverID = A1self.getView().byId("sVApproverID").getValue();
					var approverDueDateID = A1self.getView().byId("approverDueDateID").getValue();
					var FinalApproverID = A1self.getView().byId("sVFinalApproverID").getValue();
					var FinalApproverDuedate = A1self.getView().byId("finalApproverDueDateID").getValue();

					if ((AActionee === "") || (DueDate === "") || (ApproverID === "") || (approverDueDateID === "")) {
						ApproveText = "Required fields cannot be blank";
						Approvetitle = "Error";
						aprovewarning = sap.ui.core.ValueState.Error;
						visibility = false;
					} else if (AActionee === ApproverID) {
						ApproveText = "Approver cannot be same as Actionee";
						Approvetitle = "Error";
						aprovewarning = sap.ui.core.ValueState.Error;
						visibility = false;
					} else if (FinalApproverID === AActionee) {
						ApproveText = "Final approver cannot be same as Actionee";
						Approvetitle = "Error";
						aprovewarning = sap.ui.core.ValueState.Error;
						visibility = false;
					} else if (FinalApproverID === ApproverID) {
						ApproveText = "Final approver cannot be same as Approver";
						Approvetitle = "Error";
						aprovewarning = sap.ui.core.ValueState.Error;
						visibility = false;
					} else if (FinalApproverID) {
						if (FinalApproverDuedate === "") {
							ApproveText = "Site Verification Final Approver Due Date cannot be blank";
							Approvetitle = "Error";
							aprovewarning = sap.ui.core.ValueState.Error;
							visibility = false;
						}
					} else if (FinalApproverDuedate) {
						if (FinalApproverID === "") {
							ApproveText = "Site Verification Final Approver cannot be blank";
							Approvetitle = "Error";
							aprovewarning = sap.ui.core.ValueState.Error;
							visibility = false;
						}
					}

					//Submit Validation - end

					/*ApproveText = "Please confirm if site verification is required";
					Approvetitle = "Confirm";
					aprovewarning = sap.ui.core.ValueState.None;*/
				} else {
					aprovewarning = sap.ui.core.ValueState.Warning;
					ApproveText = "Please confirm if site verification is NOT required";
					Approvetitle = "Warning";
					visibility = true; //Submit Validation
				}
				//ss_Added ZX-external client_FETR0014466
			} else if (siteVerificationRole === "ZE" || siteVerificationRole === "ZX") {
				ApproveText = "Please confirm if the action is closed and submit the response.";
				Approvetitle = "Confirm";
				aprovewarning = sap.ui.core.ValueState.None;
				visibility = true; //Submit Validation

			} else if (siteVerificationRole === "ZD" && futureRole === "false") {
				ApproveText = "Please confirm if the action is closed and submit the response";
				Approvetitle = "Confirm";
				aprovewarning = sap.ui.core.ValueState.None;
				visibility = true; //Submit Validation
			}

			this.confirmdialog = new sap.m.Dialog({
				title: Approvetitle,
				type: "Message",
				state: aprovewarning,
				content: new sap.m.Text({
					text: ApproveText
				}),
				beginButton: new sap.m.Button({
					text: "Submit",
					visible: visibility,
					press: function() {
						A1self.onConfirmSubmit();
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function() {
						A1self.confirmdialog.close();
					}
				})
			});
			A1self.confirmdialog.open();
		},
		// this method regarding for submit the notification
		onConfirmSubmit: function() {
			this.confirmdialog.destroy();
			var sObjectId = this.getView().byId("idNotif").getText();
			var NotifNum = sObjectId;
			var hseLine = this.getView().byId("idHSeLine").getValue();
			var action = "A";
			var siteVarif = "";
			var A1self = this;
			var Action = "A";
			var finalData = {};
			if (A1self.getView().byId("ch1").getSelected() === true) {
				siteVarif = "X";
			}
			var aipReqir = "";
			if (A1self.getView().byId("ch2").getSelected() === true) {
				aipReqir = "X";
			}
			var zcategory1 = A1self.getView().byId("idCombo").getValue(); //getSelectedItem().getText();
			var zcategory = "";
			var combodata = ["Implemented as recommended", "Alternate solution with justification", "Recommendation not followed with reason",
				" "
			];
			if (zcategory1 === combodata[0]) {
				zcategory = "1";
			} else if (zcategory1 === combodata[1]) {
				zcategory = "2";
			} else if (zcategory1 === combodata[2]) {
				zcategory = "3";
			} else if (zcategory1 === combodata[3]) {
				zcategory = "";
			}

			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			finalData.Notifnum = NotifNum;
			finalData.HseLine = A1self.getView().byId("idHSeLine").getValue();
			finalData.Uname = sap.ushell.Container.getService("UserInfo").getUser().getId();
			finalData.Action = action;
			finalData.Zcat = zcategory;
			finalData.Aipx = aipReqir;
			finalData.Sitx = siteVarif;
			if (siteVerificationRole === "ZA") {
				if (A1self.SVActioneeChanged === true || A1self.SVDueDateChange === true || A1self.SVApproverChanged === true || A1self.SVApproverDueDateChange ===
					true || A1self.SVFinalApproverChange === true || A1self.SVFinalApproverDueDateChange === true) {
					if (A1self.getView().byId("sVActioneeID").getValue() === "") {
						sap.m.MessageBox.error("Site Verification Actionee cannot be blank");
						A1self.errorFlag = true;
					} else if (A1self.getView().byId("sVDueDate").getValue() === "") {
						sap.m.MessageBox.error("Site Verification Due Date cannot be blank");
						A1self.errorFlag = true;
					} else if (A1self.getView().byId("sVApproverID").getValue() === "") {
						sap.m.MessageBox.error("Site Verification Approver cannot be blank");
						A1self.errorFlag = true;
					} else if (A1self.getView().byId("approverDueDateID").getValue() === "") {
						sap.m.MessageBox.error("Site Verification Approver days cannot be blank");
						A1self.errorFlag = true;
					} else if (A1self.SVFinalApproverChange === true || A1self.SVFinalApproverDueDateChange === true) {
						if (this.changeBlank === true) {
							A1self.siteVerificationData(finalData);
						} else if (A1self.getView().byId("sVFinalApproverID").getValue() === "") {
							sap.m.MessageBox.error("Site Verification Final Approver cannot be blank");
							A1self.errorFlag = true;
						} else if (A1self.getView().byId("finalApproverDueDateID").getValue() === "") {
							sap.m.MessageBox.error("Site Verification Final Approver Due Date cannot be blank");
							A1self.errorFlag = true;
						} else {
							A1self.siteVerificationData(finalData);
						}
					} else {
						A1self.siteVerificationData(finalData);
					}
				} else if (A1self.SVActioneeChanged === "Changed") {
					finalData.SVActionee = "";
					finalData.SVDueDate = null;
					finalData.SVApprover = "";
					finalData.SVAppDate = "";
					finalData.SVFApprover = "";
					finalData.SVFApprDate = "";
					A1self.errorFlag = false;
				} else {
					finalData.SVActionee = "X";
					finalData.SVDueDate = null;
					finalData.SVApprover = "";
					finalData.SVAppDate = "";
					finalData.SVFApprover = "";
					finalData.SVFApprDate = "";
					A1self.errorFlag = false;
				}
			}
			if (A1self.errorFlag === false) {
				var testuser = sap.ushell.Container.getService("UserInfo").getUser().getId();

				//passlogin userid  this.vendorid 
				var Requesturl = "/SNActionSet(Action='" + Action + "',Notifnum='" + sObjectId + "',Uname='" + testuser + "',Sitx='" +
					siteVarif + "',Aipx='" + aipReqir + "',Zcat='" + zcategory + "')";
				sap.ui.core.BusyIndicator.show(0);

				setTimeout(function() {
					oModel.read(Requesturl, null,
						null,
						false,
						function(data, response) {
							if (data.EFlag !== "1") {
								if (data.EMessage !== "") {
									sap.m.MessageBox.error(data.EMessage);
								} else {
									if ((data.MsgType == "S") || (data.ReturnCode == "0")) {
										sap.m.MessageToast.show("Submission in Progress");
										if (hseLine !== "" || hseLine === "") {
											sap.ui.core.BusyIndicator.show(0);
											setTimeout(function() {
												oModel.create("/SNActionSet", finalData, {
													method: "POST",
													success: function(data, response) {
														flag = false;
														//	newDoc = [];
														A1self._onBindingChange(sObjectId); //divya(To refresh data)											
													},
													error: function(oEvent) {
														sap.ui.core.BusyIndicator.hide(); //hse_refresh_issue
														var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
														var msgLength = oMessageBox.length;
														var oMessage;
														if (msgLength === 0) {
															oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
														} else {
															oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
															if (msgLength > 0) {
																for (var msgRow = 1; msgRow < msgLength; msgRow++) {
																	oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[msgRow].message;
																}
															}
														}
														sap.m.MessageBox.error(oMessage);
													}
												});

											});
										}

										//sap.ui.core.BusyIndicator.show(); // hse_refresh_issue
										//	sap.ui.core.routing.HashChanger.getInstance().replaceHash("");
										//	masterthis.onInit();
										/*sap.ui.getCore().byId("list").getBinding("items").refresh(); */ //submit Validations
										masterthis.getView().byId("list").getBinding("items").refresh();
										//A1self._onBindingChange(); // hse_refresh_issue
										flag = false;
									} else {
										sap.ui.core.BusyIndicator.hide(); //hse_refresh_issue
										sap.m.MessageToast.show("Notification approval failed");
										flag = false;
									}
								}
							} else {
								sap.ui.core.BusyIndicator.hide(); //hse_refresh_issue
								sap.m.MessageBox.error("Please Unlock " + NotifNum + " and reprocess again");
							}
						},
						function(oEvent) {
							var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
							var msgLength = oMessageBox.length;
							var oMessage;
							if (msgLength === 0) {
								oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
							} else {
								oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
								if (msgLength > 0) {
									for (var msgRow = 1; msgRow < msgLength; msgRow++) {
										oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[msgRow].message;
									}
								}
							}
							sap.m.MessageBox.error(oMessage);

						});
					// sap.ui.core.BusyIndicator.hide();
				});
			}
		},
		//* For downloading the  Reference Files 
		getpdf: function(oEvent) {
			var getArcDocID = oEvent.getSource().getProperty("target").split("-");
			var arcDocId = encodeURIComponent(getArcDocID[0]);
			var filename = oEvent.getSource().getProperty("text");
			var rfqNo = getArcDocID[1];
			var sRead = "/SN_AttachmentSet(IObjId='" + rfqNo + "',ArcDocId='" + arcDocId + "')";
			var sURI = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV" + sRead + "/$value";
			sURI = encodeURI(sURI);
			window.open(sURI, filename);
		},
		//Remove the File Attachment from my Attachments
		handleRemoveAttachments: function(oEvent) {
			var deleteFile = oEvent;
		},
		//* For File Uploading for each SN's
		handleUploadPress1: function(oEvent) {
			var serviceURL = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var RequestUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV/SN_AttachmentSet";
			var oModel = new sap.ui.model.odata.ODataModel(serviceURL);
			var Des = this;
			var oFileUploader = this.getView().byId("fileUploader");
			var fileName = oFileUploader.getValue();
			if (oFileUploader.getValue() === "") {
				sap.m.MessageToast.show("Please select any Evidence File");
			} else if (fileName.length > 64) {
				sap.m.MessageBox.alert("File name cannot be more than 64 characters");
				this.getView().byId("fileUploader").setValue("");
			} else {
				var dialog = new sap.m.Dialog({
					title: 'Enter Description for the attachment',
					type: 'Message',
					content: [
						new sap.m.Input('confirmDialogTextarea', {
							width: '30rem',
							hight: '20%',
							maxLength: 60,
							value: fileName.slice(0, -4)
						})
					],
					beginButton: new sap.m.Button({
						text: 'Submit',
						press: function() {
							sap.ui.core.BusyIndicator.show(0);
							//ss_Submit button disable
							Des.getView().byId("acceptStaus").setEnabled(false);
							//ss_UploadButton disable
							Des.getView().byId("idUploadFileButton").setEnabled(false);
							setTimeout(function() {
								if (Des.getView().byId("idHSeLine").getValue().length > 0) {
									Des.saveFlag = true;
									uploadPress = true;
									Des.onSaveForDrapt();
								}
								var userName = sap.ushell.Container.getService("UserInfo").getUser().getId();
								var notifNum = Des.getView().byId("idNotif").getText();
								var fileName = sap.ui.getCore().byId('confirmDialogTextarea').getValue();

								var filetitle = fileName;
								//SS_Attach the doc with same file name_error message
								var oFileUploader2 = Des.getView().byId("fileUploader");
								var exfileName = oFileUploader2.getValue();
								var currentuserModel = Des.getView().byId("idMyCureentuser").getModel("currentuserModel").getData();
								var errorFlag = true;
								if (currentuserModel.length > 0) {
									for (var i = 0; i < currentuserModel.length; i++) {
										if (currentuserModel[i].Filename === exfileName) {
											sap.ui.core.BusyIndicator.hide();
											dialog.close();
											sap.m.MessageBox.error("An attachment with the same file name already exists. Please use another file name", {
												actions: sap.m.MessageBox.Action.CLOSE,
												onClose: null
											});
											//sap.m.MessageToast.show("An attachment with the same file name already exists. Please use another file name");
											errorFlag = false;
											Des.getView().byId("idUploadFileButton").setEnabled(true);
										}
									}

								}

								if (errorFlag) {

									// newDoc.push(filetitle);
									var Myslug = filetitle + "|" + Des.getView().byId("fileUploader").getValue() + "|" + notifNum + "|" + userName;
									oModel.refreshSecurityToken();
									oFileUploader.insertHeaderParameter(new sap.ui.unified.FileUploaderParameter({
										name: "x-csrf-token",
										value: oModel.getHeaders()['x-csrf-token']
									}));
									oFileUploader.insertHeaderParameter(new sap.ui.unified.FileUploaderParameter({
										name: "slug",
										value: Myslug //filetitle + "|" + Des.getView().byId("fileUploader").getValue() + "|" + notifNum + "|" + userName //title as sText
									}));
									oFileUploader.insertHeaderParameter(new sap.ui.unified.FileUploaderParameter({
										name: "Content-Type",
										value: "pdf"
									}));
									oFileUploader.setSendXHR(true);
									oFileUploader.setUploadUrl(RequestUrl);
									sap.m.MessageToast.show("Uploading in progress.  Please wait.");
									oFileUploader.upload();
									// Myslug= "";
									dialog.close();
								}

							});
						}
					}),
					endButton: new sap.m.Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			}
		},
		// for Category Validations
		onchange: function() {
			alert("change");
		},

		handleEvent: function() {
			var combo_Id = this.getView().byId("idCombo");
			var allItem = combo_Id.getItems();
			var arr = [];
			var value = combo_Id.getValue().trim();
			for (var i = 0; i < allItem.length; i++) {
				arr.push(allItem[i].getText());
			}
			if (arr.indexOf(value) < 0) {
				combo_Id.setValueState("Error");
				combo_Id.setValue();
			} else {
				combo_Id.setValueState("None");
			}
		},

		//* For file upload success/error  indication.
		handleUploadComplete: function(oEvent) {
			var sResponse = oEvent.getParameter("status");
			var sResponseText = oEvent.getParameter("response");
			if (sResponseText) {
				sResponseText = sResponseText.charAt(sResponseText.length - 1);
			}
			var notifNum = this.getView().byId("idNotif").getText();
			var that = this;
			sap.ui.core.BusyIndicator.hide();
			if (sResponse) {
				var sMsg = "";
			// start of changes by FETR0013156	
				if (sResponse === 201 && sResponseText === "X") {
					var displayStatus1 = this.getResourceBundle().getText("informationAttachmentInProgress");
					// sMsg = "Attachment upload inprogress, please wait for a min";
					oEvent.getSource().setValue("");
					sap.m.MessageBox.information(displayStatus1, {
						styleClass: "messageboxClass",
						//ss_Submit button enable
						onClose: function() {
							that.getView().byId("acceptStaus").setEnabled(true);
							//ss_UploadFile button enable
							that.getView().byId("idUploadFileButton").setEnabled(true);
						}
					});
					this._onBindingChange(notifNum);         //end of changes FETR0013156
				} else if (sResponse === 201) {
					sMsg = "Attachment successfully Uploaded and Data has been saved";
					// if (this.getView().byId("idHSeLine").getValue().length > 0) {
					// 			this.saveFlag = true;
					// 			uploadPress = true;
					// 			this.onSaveForDrapt();
					// 		}
					//	newDoc.push(oEvent.getParameter("fileName"));
					oEvent.getSource().setValue("");

					sap.m.MessageBox.success(sMsg, {
						styleClass: "messageboxClass",
						//ss_Submit button enable
						onClose: function() {
							that.getView().byId("acceptStaus").setEnabled(true);
							//ss_UploadFile button enable
							that.getView().byId("idUploadFileButton").setEnabled(true);
						}
					});
					this._onBindingChange(notifNum);
				} else {
					var oMessageBox = jQuery.parseXML(oEvent.getParameter("responseRaw")).querySelectorAll("errordetail > message");
					var msgLength = oMessageBox.length;
					var oMessage;
					if (msgLength === 0) {
						oMessage = jQuery.parseXML(oEvent.getParameter("responseRaw")).querySelectorAll("errordetail > message")[0].textContent;
					} else {
						oMessage = jQuery.parseXML(oEvent.getParameter("responseRaw")).querySelectorAll("errordetail > message")[0].textContent;
						if (msgLength > 0) {
							for (var msgRow = 1; msgRow < msgLength; msgRow++) {
								oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[msgRow].textContent;
							}
						}
					}
					sap.m.MessageBox.error(oMessage, {
						//ss_submit button enable
						onClose: function() {
							that.getView().byId("acceptStaus").setEnabled(true);
							//ss_UploadFile button enable
							that.getView().byId("idUploadFileButton").setEnabled(true);
						}

					});

					// 	sMsg = "Error in uploading attachment";
					// //	newDoc.pop();
					// 	oEvent.getSource().setValue("");
					// 	sap.m.MessageBox.error(sMsg, {
					// 		styleClass: "messageboxClass"
					// 	});
				}
			}
		},

		//* For checking the choosen file  is valid formate .
		handleTypeMissmatch: function(oEvent) {
			sap.m.MessageBox.error("Please attach PDF file only");
		},

		onExit: function(oEvent) {
			flag = false;
			// Open the Table Setting dialog
		},

		//* Actions for  Aip action  When user wants to Agree in Principle for  the perticular SN's
		onAip: function() {
			// if (this.getView().byId("ch2").getSelected() !== true) {
			// 	// sap.m.MessageBox.alert("Please check AIP Required", {
			// 	// 	icon: sap.m.MessageBox.Icon.INFO,
			// 	// 	title: "Info"
			// 	// });
			// 	sap.m.MessageBox.error("Please check AIP Required", {
			// 		title: "Error", // default
			// 		textDirection: sap.ui.core.TextDirection.Inherit // default
			// 	});
			// } else {
			var action = "P";
			var siteVarif = "";
			var A1self = this;
			if (A1self.getView().byId("ch1").getSelected() === true) {
				siteVarif = "X";
			}
			var aipReqir = "";
			if (A1self.getView().byId("ch2").getSelected() === true) {
				aipReqir = "X";
			}
			var zcategory1 = A1self.getView().byId("idCombo").getValue(); //getSelectedItem().getText();
			var zcategory = "";
			var combodata = ["Implemented as recommended", "Alternate solution with justification", "Recommendation not followed with reason",
				" "
			];
			if (zcategory1 === combodata[0]) {
				zcategory = "1";
			} else if (zcategory1 === combodata[1]) {
				zcategory = "2";
			} else if (zcategory1 === combodata[2]) {
				zcategory = "3";
			} else if (zcategory1 === combodata[3]) {
				zcategory = "0";
			}
			//	service call for save data 
			var sObjectId = this.getView().byId("idNotif").getText();
			var finalData = {};
			var NotifNum = sObjectId;
			var hseLine = A1self.getView().byId("idHSeLine").getValue();
			finalData.Notifnum = NotifNum;
			finalData.HseLine = A1self.getView().byId("idHSeLine").getValue();
			finalData.Uname = sap.ushell.Container.getService("UserInfo").getUser().getId();
			finalData.Action = action;
			finalData.Zcat = zcategory;
			finalData.Aipx = aipReqir;
			finalData.Sitx = siteVarif;
			var Action = "P";
			finalData.Action = Action;
			finalData.Notifnum = sObjectId;
			var suname = sap.ushell.Container.getService("UserInfo").getUser().getId();
			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				content: new sap.m.Text({
					text: 'Are you sure you want to Agree In Principle?'
				}),
				beginButton: new sap.m.Button({
					text: 'Submit',
					press: function() {
						var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
						//	var sObjectId = A1self.getView().byId("idNotif").getText();
						var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
						finalData.Notifnum = NotifNum;
						finalData.HseLine = A1self.getView().byId("idHSeLine").getValue();
						finalData.Uname = sap.ushell.Container.getService("UserInfo").getUser().getId();
						finalData.Action = action;
						finalData.Zcat = zcategory;
						finalData.Aipx = aipReqir;
						finalData.Sitx = siteVarif;
						var Requesturl = "/SNActionSet(Action='" + Action + "',Notifnum='" + NotifNum + "',Uname='" + suname + "',Sitx='" +
							siteVarif + "',Aipx='" + aipReqir + "',Zcat='" + zcategory + "')";
						sap.ui.core.BusyIndicator.show(0);
						setTimeout(function() {
							oModel.read(Requesturl, null,
								null,
								false,
								function(data, response) {
									if (data.EFlag !== "1") {
										if ((data.MsgType === "") || (data.ReturnCode === "0")) {
											sap.m.MessageToast.show("Submission in Progress");
											if (hseLine !== "" || hseLine === "") {
												sap.ui.core.BusyIndicator.show(0);
												setTimeout(function() {
													oModel.create("/SNActionSet", finalData, {
														method: "POST",
														success: function(data, response) {
															flag = false;
														},
														error: function(oEvent) {
															var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
															var msgLength = oMessageBox.length;
															var oMessage;
															if (msgLength === 0) {
																oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
															} else {
																oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
																if (msgLength > 0) {
																	for (var msgRow = 1; msgRow < msgLength; msgRow++) {
																		oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[
																			msgRow].message;
																	}
																}
															}
															sap.m.MessageBox.error(oMessage);
															// if (hseLine === "") {}
														}
													});
													sap.ui.core.BusyIndicator.hide();
												});
											}
											//	sap.ui.core.routing.HashChanger.getInstance().replaceHash("");
											//	masterthis.onInit();
											masterthis.getView().byId("list").getBinding("items").refresh();
											A1self._onBindingChange();
											flag = false;
										} else {
											sap.m.MessageToast.show("Notification approval failed");
											flag = false;
										}
									} else {
										sap.m.MessageBox.error("Please Unlock " + NotifNum + " and reprocess again");
									}
								},
								function(oEvent) {
									var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
									var msgLength = oMessageBox.length;
									var oMessage;
									if (msgLength === 0) {
										oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
									} else {
										oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
										if (msgLength > 0) {
											for (var msgRow = 1; msgRow < msgLength; msgRow++) {
												oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[msgRow].message;
											}
										}
									}
									sap.m.MessageBox.error(oMessage);
								});
							sap.ui.core.BusyIndicator.hide();
						});
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
			//	}
		},
		showBusyIndicator: function(iDuration, iDelay) {
			sap.ui.core.BusyIndicator.show(iDelay);

			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null;
				}

				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function() {
					this.hideBusyIndicator();
				});
			}
		},
		hideBusyIndicator: function() {
			sap.ui.core.BusyIndicator.hide();
		},
		onDeleteDailog: function(oEvent) {
			this.deleteObj = oEvent.getSource().data("DeleteObject");
			this.dialog = sap.ui.xmlfragment("zsnotif.view.DeleteAttacmentDialog", this);
			this.dialog.open();

		},
		/*function name : destroyDialog*/
		/*Reason :  to destroy dialog box */
		/*input parameters: parameters*/

		destroyDialog: function() {
			this.dialog.destroy();
		},
		// delete Attachment method 
		onDelete: function() {
			var self = this;
			var sMsg = "";
			self.dialog.destroy();
			if (self.getView().byId("idHSeLine").getValue().length > 0) {
				self.saveFlag = true;
				deletePress = true;
				self.onSaveForDrapt();
			}
			var sServiceUrl = "/sap/opu/odata/sap/ZENG_SN_APPROVE_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var notifNum = self.deleteObj.NotifNum;
			var req_url = "/SN_AttachmentSet(IObjId='" + this.deleteObj.NotifNum + "',ArcDocId='" + this.deleteObj.ArcDocId + "')";
			sap.ui.core.BusyIndicator.show(0);
			setTimeout(function() {
				oModel.remove(req_url, {
					method: "DELETE",
					success: function(oData, oResponse) {
						//// Added by Bharat to freeze the screen at MY Attachment /////
						deleteScroll = "X";
						sMsg = "Document Deleted successfully and Data has been saved";
						self._onBindingChange(notifNum);
						sap.m.MessageBox.success(sMsg);
					},
					error: function(oEvent) {
						// var oMessageBox = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails;
						// var msgLength = oMessageBox.length;
						// var oMessage;
						// if (msgLength === 0) {
						// 	oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
						// } else {
						// 	oMessage = jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[0].message;
						// 	if (msgLength > 0) {
						// 		for (var msgRow = 1; msgRow < msgLength; msgRow++) {
						// 			oMessage = oMessage + "\n" + jQuery.parseJSON(oEvent.response.body).error.innererror.errordetails[msgRow].message;
						// 		}
						// 	}
						// }
						// sap.m.MessageBox.error(oMessage);
						sap.m.MessageBox.error(jQuery.parseJSON(oEvent.response.body).error.message.value);
						// sMsg = "Document Deletion Field";
						// var oMessage = JSON.parse(ex.response.body);
						// sap.m.MessageBox.error(oMessage.error.innererror.errordetails[0].message);
					}
				});
				sap.ui.core.BusyIndicator.hide();
			});
		},
		siteVerificationData: function(finalData) {
			finalData.SVActionee = this.getView().byId("sVActioneeID").getValue();
			var SVDueDate = this.getView().byId("sVDueDate").getValue();
			var finalSVDueDate;
			if (SVDueDate === "" || SVDueDate === null) {
				finalSVDueDate = null;
			} else {
				var sVADate = this.getView().byId("sVDueDate").getValue().split("/");
				if (sVADate.length < 3) {
					sVADate = this.getView().byId("sVDueDate").getValue().split("-");
					if (sVADate.length === 3) {
						var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
						var month = monthNames.indexOf(sVADate[1]) + 1;
						var sVAformattedDate = sVADate[2] + "-" + month + "-" + sVADate[0] + "T00:00:00";
					} else {
						var sVAformattedDate = sVADate[2] + "-" + sVADate[1] + "-" + sVADate[0] + "T00:00:00";
					}
					if (sVADate.length < 3) {
						sVADate = this.getView().byId("sVDueDate").getValue().split(".");
						sVAformattedDate = sVADate[2] + "-" + sVADate[1] + "-" + sVADate[0] + "T00:00:00";
					}
				} else {
					sVAformattedDate = sVADate[2] + "-" + sVADate[1] + "-" + sVADate[0] + "T00:00:00";
				}
				finalSVDueDate = sVAformattedDate;
			}
			finalData.SVDueDate = finalSVDueDate;
			finalData.SVApprover = this.getView().byId("sVApproverID").getValue();
			var SVAppDate = this.getView().byId("approverDueDateID").getValue();
			finalData.SVAppDate = SVAppDate;
			finalData.SVFApprover = this.getView().byId("sVFinalApproverID").getValue();
			var SVFApprDate = this.getView().byId("finalApproverDueDateID").getValue();
			finalData.SVFApprDate = SVFApprDate;
			this.errorFlag = false;
		}

	});

});