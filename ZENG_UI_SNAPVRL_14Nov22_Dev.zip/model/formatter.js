sap.ui.define([], function() {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */

		//using	

		formatDate: function(value) {
			if (value) {
				var date2 = value.split("-");
				value = date2[2] + "-" + date2[1] + "-" + date2[0];
				return value;
			} else {
				return value;
			}
		},
		formatDate3: function(value) {
			if (value) {
				var date2 = value.split("T")[0].split("-");
				var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
				return date2[2] + "-" + monthNames[parseInt(date2[1]) - 1] + "-" + date2[0];
			} else {
				return value;
			}
		},
		HeaderText: function(sValue) {
			if (!sValue) {
				return "";
			}
			var str = sValue;
			var arr = str.split("#$#");
			if (arr.length > 0) {
				var text = "";
				var i;
				for (i = 0; i < arr.length; i++) {
					text += arr[i] + "\n";
				}
				return text.trim();
			} else {
				return sValue;
			}
		},
		formatDate2: function(value) {
			if (value) {
				value = value.toString().slice(0, 15);
				var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
				var value = new Date(value);
				return value.getDate() + '-' + monthNames[value.getMonth()] + '-' + value.getFullYear();
			} else {
				return value;
			}
		},
		formatAvailableToObjectState: function(date) {
			var value = new Date();
			var dateSecond = date; //new Date(date).toJSON().slice(0, 10).replace(/-/g, '/');
			value = value.toString().slice(4, 15);
			var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
			value = new Date(value);
			var getmonth = value.getMonth() + 1;
			if (Number(getmonth) < 10) {
				var month = ["0"] + getmonth;
			} else {
				var month = getmonth;
			}
			if (Number(value.getDate()) < 10) {
				var day = ["0"] + value.getDate();
			} else {
				var day = value.getDate();
			}
			var today = value.getFullYear() + '-' + month + '-' + day;
			var browserdate = date.split("-");
			var month1;
			for (var i = 0; i < monthNames.length; i++) {
				if (browserdate[1] === monthNames[i]) {
					month1 = i + 1;
					break;
				}
			}

			if (Number(month1) < 10) {
				month1 = ["0"] + month1;
			}
			var dueDate = browserdate[0] + "-" + month1 + "-" + browserdate[2];
			if (new Date(today) > new Date(dueDate)) {
				return "Error";
			}
			if (new Date(today) < new Date(dueDate)) {
				return "None";
			}
		}
	};

});